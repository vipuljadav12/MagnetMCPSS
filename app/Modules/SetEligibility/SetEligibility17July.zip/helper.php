<?php

/**
 *	SetEligibility Helper  
 */
function getEligibilityContent($id)
{
	// return $id;
	if(isset($id)){
		$Eligibility = new  App\Modules\Eligibility\Models\Eligibility;
		$EligibilityContent = new  App\Modules\Eligibility\Models\EligibilityContent;
		$EligibilityTemplate = new  App\Modules\Eligibility\Models\EligibilityTemplate;
		$content = $EligibilityContent->where("eligibility_id",$id)->first();
		$eligibility = $Eligibility->where("id",$content->eligibility_id)->first();
		$eligibilityTemplate = $EligibilityTemplate->where("id",$eligibility->template_id)->first();
		// return  $eligibilityTemplate->content_html;
		// return $eligibility;
		// return $content;
		$html = "";
		if(isset($content->content))
		{
			$data = json_decode($content->content);
			if(isset($eligibilityTemplate->content_html) && ($eligibilityTemplate->content_html == "interview" ||$eligibilityTemplate->content_html == "writing_prompt" || $eligibilityTemplate->content_html ==  "committee_score" || $eligibilityTemplate->content_html ==  "audition"  ))
			{
				$type = $data->eligibility_type->type;
				// return  $type;
				$options = $data->eligibility_type->$type;
				foreach($options as $o=>$option)
				{
					$html .= '<option value="'.$option.'">'.$option.'</option>';
				}
				// dd($html);
				// return $data;
			}
			if(isset($eligibilityTemplate->content_html) && ($eligibilityTemplate->content_html == "academic_grade_calculation" || $eligibilityTemplate->content_html == "standardized_testing" || $eligibilityTemplate->content_html == "conduct_disciplinary"))
			{
				// return  $content->content;
				/*print_r("dd");
				dd('dd');
				return $data;*/
				// $html .= "deede";
				$type = $data->scoring->method;
				// return  $type;
				$options = $data->scoring->$type;
				foreach($options as $o=>$option)
				{
					$html .= '<option value="'.$option.'">'.$option.'</option>';
				}
				// dd($html);
				// return $data;
			}
			
		}
		return $html;
		return $content->content;
	}
}