<?php

Route::group(['prefix'=>'admin/SetEligibility','module' => 'SetEligibility', 'middleware' => ['web','auth'], 'namespace' => 'App\Modules\SetEligibility\Controllers'], function() {

    Route::get('/edit/{id}', 'SetEligibilityController@edit');
    Route::resource('/', 'SetEligibilityController');

});
