<?php

namespace App\Modules\SetEligibility\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\District\Models\District;
use App\Modules\Eligibility\Models\Eligibility;
use App\Modules\Eligibility\Models\EligibilityTemplate;
use App\Modules\Program\Models\Program;
use App\Modules\Program\Models\ProgramEligibility;
use App\Modules\Priority\Models\Priority;
use Session;
use View;

class SetEligibilityController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->url = url("admin/SetEligibility");
        View::share(["module_url"=>$this->url]);
    }
    public function index()
    {
        if(\Session::get("district_id") != '0')
            $programs=Program::where('status','!=','T')->where('district_id', \Session::get('district_id'))->get();
        else
            $programs=Program::where('status','!=','T')->get();
        // return $programs;
        // return view("Program::index",compact('programs'));
        return view("SetEligibility::index",compact('programs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $district=District::where('id',session('district_id'))->first();

        $priorities = Priority::where('district_id', session('district_id'))->where('status', '!=', 'T')->get();
        $program=Program::where('id',$id)->first();
        $programeligibilities=ProgramEligibility::where('program_id',$id)->get();
        // return $programeligibilities;
        $eligibility_templates=EligibilityTemplate::all()->toArray();
        // $eligibility_templates[] = array("id"=>0,"name"=>"Template 2");
        // return $eligibility_templates;
        $eligibility_types=Eligibility::where('status','Y')->where('district_id', Session::get('district_id'))->get();
        $eligibilities=null;
        foreach ($eligibility_templates as $k=>$eligibility_template)
        {
            $eligibility=null;
            foreach ($eligibility_types as $key=>$eligibility_type)
            {
                if ($eligibility_template['id']==$eligibility_type->template_id)
                {
                    $eligibility[]=$eligibility_type;
                }
                /*if($eligibility_type->template_id == 0){
                    $eligibility[]=$eligibility_type;
                }*/

            }
            if ($eligibility!=null)
            {
                $eligibilities[]=array_merge($eligibility_template,array('eligibility_types'=>$eligibility));
            }
        }
        // return $eligibilities;
//        return $programeligibilities[0]->eligibility_type;
        foreach ($eligibilities as $key=>$eligibility)
        {
            foreach ($programeligibilities as $k=>$programeligibility)
            {
                if ($programeligibility->eligibility_type==$eligibility['id'])
                {
                    $eligibilities[$key]['program_eligibility']=$programeligibility;
                }
            }
        }
        // return $eligibilities;
        return view('SetEligibility::edit',compact('program','eligibilities','priorities','district'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
