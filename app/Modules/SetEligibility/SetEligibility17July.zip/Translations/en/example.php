<?php 

return [
    'welcome' => 'Welcome, this is SetEligibility module.'
];
