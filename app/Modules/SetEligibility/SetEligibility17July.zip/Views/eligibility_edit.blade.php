<div class="">
    <div class="card shadow">
        <div class="card-header d-flex flex-wrap justify-content-between">
            <div class="">Eligibility Determination Method</div>
            
        </div>
        <div class="card-body">
            <div class="pb-10 d-flex flex-wrap justify-content-center align-items-center">
                <div class="d-flex mb-10 mr-30">
                    <div class="mr-10">Basic Method Active : </div>
                    <input disabled="" id="basic_method_only" type="checkbox" class="js-switch js-switch-1 js-switch-xs" name="basic_method_only"  data-size="Small" {{$program->basic_method_only=='Y'?'checked':''}}>
                </div>
                <div class="d-flex mb-10 mr-30">
                    <div class="mr-10">Combined Scoring Active : </div>
                    <input disabled="" id="combined_scoring" type="checkbox" class="js-switch js-switch-1 js-switch-xs"  name="combined_scoring" data-size="Small" {{$program->combined_scoring=='Y'?'checked':''}}>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                    <tr>
                        <th class="align-middle">Eligibility Type</th>
                        <th class="align-middle">Used in Determination Method</th>
                        <th class="align-middle text-center">Eligibility Value Required?</th>
                        <th class="align-middle text-center">Minimum Eligibility Value</th>
                        <th class="align-middle text-center">On/Off</th>
                        <th class="align-middle text-center w-120">Applied to Grades</th>
                    </tr>
                    </thead>
                    <tbody>
                        @forelse($eligibilities as $key=>$eligibility)
                            <tr>
                                <td class="">
                                    {{$eligibility['name']}}
                                    <input type="hidden" id="" name="eligibility_type[]" value="{{$eligibility['id']}}">
                                </td>
                                <td class="">
                                    <select class="form-control custom-select" name="determination_method[]" disabled>
                                       <option value="">Choose an Option</option>
                                        <option value="Basic" {{isset($eligibility['program_eligibility']['determination_method']) && $eligibility['program_eligibility']['determination_method']=='Basic'?'selected':''}}>Basic</option>
                                        <option value="Combined" {{isset($eligibility['program_eligibility']['determination_method']) &&    $eligibility['program_eligibility']['determination_method']=='Combined'?'selected':''}}>Combined</option>
                                    </select>
                                </td>
                                <td class="text-center">
                                    <select class="form-control custom-select valueRequiredSelect">
                                        <option value="">Choose an Option</option>
                                        <option value="Y">Yes</option>
                                        <option value="N">No</option>
                                    </select>
                                </td>
                                <td class="text-center">
                                    <div class="MinimumEligibility ForSelectedY">
                                        <select class="form-control">
                                            @if(isset($eligibility['program_eligibility']['assigned_eigibility_name']))
                                                {!! getEligibilityContent($eligibility['program_eligibility']['assigned_eigibility_name']) ?? "" !!}
                                            @endif
                                        </select>
                                        @if(isset($eligibility['program_eligibility']['assigned_eigibility_name']))
                                            {{-- {!! getEligibilityContent($eligibility['program_eligibility']['assigned_eigibility_name']) ?? "" !!} --}}
                                        @endif
                                       {{$eligibility['program_eligibility']['assigned_eigibility_name'] ?? ""}}
                                    </div>
                                    <div class="MinimumEligibility ForSelectedN d-none">
                                        N/A
                                    </div>
                                    {{-- <select class="form-control custom-select assigned_eigibility_name" id="interview_score_eligi_name" name=" assigned_eigibility_name[]">
                                        <option value="">Choose an Option</option>
                                        @forelse($eligibility['eligibility_types'] as $k=>$eligibility_types)
                                            <option value="{{$eligibility_types['name']}}" {{isset($eligibility['program_eligibility']['assigned_eigibility_name'])&&$eligibility['program_eligibility']['assigned_eigibility_name']==$eligibility_types['name']?'selected':''}}>{{$eligibility_types['name']}}</option>
                                        @empty
                                        @endforelse
                                    </select> --}}
                                </td>
                                <td class="text-center">
                                    <input id="chk_09" name="status[{{$eligibility['id']}}][]" type="checkbox" class="js-switch js-switch-1 js-switch-xs eligibility_status" data-size="Small" {{isset($eligibility['program_eligibility']['status'])&&$eligibility['program_eligibility']['status']=='Y'?'checked':''}}>
                                </td>
                                <td class="text-center">
                                    <input type="text" disabled="" class="form-control" name="" value="{{$eligibility['program_eligibility']['grade_lavel_or_recommendation_by'] ?? ""}}">                                    
                                </td>
                            </tr>
                        @empty
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>