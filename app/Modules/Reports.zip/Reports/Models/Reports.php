<?php

namespace App\Modules\Reports\Models;

use Illuminate\Database\Eloquent\Model;

class Reports extends Model {

   

}
