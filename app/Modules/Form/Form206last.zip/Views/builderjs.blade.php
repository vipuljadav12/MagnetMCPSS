<script type="text/javascript">
	var inputJson = new Array();
	$("#draggable > div").each(function(){
        $(this).draggable({
            connectToSortable: '.spacer',
            containment: ".card-body",
            cursor: 'move',
            helper: 'clone',
            zIndex: 100,
            stop : function(event, ui){
                box_control(this);
                var curr = $('.spacer').children('.cust-box-out');
                if(curr.length > 0) {
                    hideElement();    
                }
            },
            revert: "invalid",
            scroll: false,
        });
    });
    $(function()
    {
    	getFormContent();
    });
    function getFormContent()
    {
    	// var form_id = $(document).find("form_id").val();
    	var form_id = "{{$form->id}}";
    	// alert(form_id);
    	$.ajax({
			url: '{{url("admin/Form/getFormContent")}}',
			type: 'GET',
			data: {
				form_id:form_id
			},
			success: function(data) {
				$(document).find(".input_container_builder").html(data);
			},
		});
    }
    /*$(document).on("mouseover",".form-group-input",function()
    {
    	$(this).addClass();
    });*/
	// console.log(inputJson);
	$(document).on("dblclick",".field-type-menu-item",function()
	{
		var fieldType = $(this).attr("data-type");
		var fieldID = $(this).attr("data-type-id");
		var form_id = $(this).attr("data-form-id");
		// alert(fieldType);
		$.ajax({
			url: '{{url("admin/Form/insertField")}}',
			type: 'GET',
			data: {
				type:fieldType,
				field_id:fieldID,
				form_id:form_id
			},
			success: function(data) {
				// $(document).find(".input_container_builder").append(data);
    			getFormContent();

			},
		});
	});
	$(document).on("click",".removeField",function()
	{
		var build_id = $(this).parent().parent().attr("data-build-id");
		$.ajax({
			url: '{{url("admin/Form/removeField/")}}'+"/"+build_id,
			type: 'GET',
			success: function(data) {
    			getFormContent();
			},
		});
	});
	$(document).on("click",".form-group-input",function()
	{
		$(this).siblings().removeClass("selectedForChange").addClass("form-group-input");
		$(this).addClass("selectedForChange").removeClass("form-group-input");
		$(document).find("#fieldEditor").html();
		$(document).find("#fieldEditor").addClass("d-none");
		var build_id = $(this).attr("data-build-id");
		$.ajax({
			url: '{{url("admin/Form/fieldEditor/")}}'+"/"+build_id,
			type: 'GET',
			success: function(data) {
    			// getFormContent();
    			$(document).find("#fieldEditor").html(data);
				$(document).find("#fieldEditor").removeClass("d-none");

			},
		});

	});
	$(document).on("change input",".editorInput",function()
	{
		var value = $(this).val();
		var dataFor = $(this).attr("data-for");
		var build_id = $(this).attr("build-id");
		if(dataFor == "label")
		{
			$(document).find("#label"+build_id).html(value);
		}
		if(dataFor == "placeholder")
		{
			$(document).find("#input"+build_id).attr("placeholder",value);
		}
	});
	$(document).on("blur",".editorInput",function()
	{
		var value = $(this).val();
		var dataFor = $(this).attr("data-for");
		var build_id = $(this).attr("build-id");
		$.ajax({
			url: '{{url("admin/Form/saveSingle/")}}',
			type: 'POST',
			data:
			{
				_token:"{{csrf_token()}}",
				field_property:dataFor,
				field_value:value,
				build_id:build_id,
				form_id:'{{$form->id}}'

			},
			success: function(data) {
    			console.log(data);
			},
		});
		
	});
	$(document).on("click",".saveFormCreate",function()
	{
		var allInputs = $(document).find(".inputToSave").attr("data-name");
		var allInputsValues = new Array();
		$(document).find(".form-input-group").each(function(key)
		{
			if($(this).attr("data-type") == "text")
			{
				var currentInput = new Array();
				currentInput["label"] = $(this).find(".inputLabel").html();
				currentInput["placeholder"] = $(this).find(".placeholderInput").text();
				currentInput["type"] = $(this).find(".typeChangeInput").val();
				checkRequired= $(this).find(".inputCheckBoxRequired").prop("checked");
				currentInput["required"]  = checkRequired == true ? "y" : "n";
				
			}
			// allInputsValues.push(currentInput);
			allInputsValues[key] = currentInput;
			// allInputsValues[input_name] = $(this).html();
		});
		console.log(allInputsValues);
		var form_id = $(document).find("#form_id").val();
		$.ajax({
		  url: '{{url("admin/Form/saveBuild")}}',
		  type: 'post',
		  data: {
		 	_token:"{{csrf_token()}}",
		 	data:allInputsValues,
		 	form_id:form_id
		  },
		  success: function(data) {
		    $(document).find(".input_container_builder").append(data);
		  },
		});
		/*$(document).find(".inputToSave").each(function()
		{
			var input_name = $(this).attr("data-name");
			allVal[input_name] = $(this).html();
		});*/
		// console.log(allInputs);
	});
	$(document).on("input change",".placeholderInput",function()
	{
		$(this).parent().find(".inputText").attr("placeholder",$(this).html());
	});
	$(document).on("change",".typeChangeInput",function()
	{
		$(this).parent().find("input").attr("type",$(this).val());
	});
	
	$(document).on("focus",".inputToSave",function()
	{
		$(this).addClass("input-border");
	});
	$(document).on("focusout",".inputToSave",function()
	{
		$(this).removeClass("input-border");
	});
</script>