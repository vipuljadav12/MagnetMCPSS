<?php

/**
 *	From Helper  
 */

function getValuesForms()
{
	return "here";
}
function getFieldBox($field_id)
{
	$field = DB::table("form_fields")->where("id",$field_id)->first();
	return $field;
}
function getContentValue($build_id,$field_property)
{
	$content = DB::table("form_content")->where("build_id",$build_id)->where("field_property",$field_property)->first();
	if(isset($content))
	{
		return $content->field_value;
	}
	else
	{
		// return "";
	}
}