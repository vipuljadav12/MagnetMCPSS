<style type="text/css">
    .input-border
    {
        border:1px solid rgba(192,192,192,0.5) !important;
        padding:1px !important;
    }
    .mt5
    {
        margin-top: 5px !important;
    }
    .mb5
    {
        margin-bottom: 5px !important;
    }
</style>
<div class="">
    <div class="row">
        <div class="col-12 col-md-2">
            <ul class="list-unstyled">
                {{-- @php
                    $fields = array(
                        "Textbox","Textarea","Check Box","Radio","Drop Down","Ckeditor","Button"
                    );
                @endphp --}}
                {{-- @foreach($fields as $f=>$field)
                    here 
                    <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="{{strtolower(str_replace("_", "",$field))}}">
                        <i class="fas fa-ellipsis-v mr-10"></i><i class="fas fa-font"></i> <span>{{$field ?? ""}}</span>
                    </li>
                @endforeach --}}
                @forelse($formFields as $fld=>$formField)
                    <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="{{$formField->type}}" data-type-id="{{$formField->id}}" data-form-id="{{$form->id}}">
                        <i class="fas fa-ellipsis-v mr-10"></i><i class="{{$formField->icon ?? ""}}"></i> <span>{{$formField->name ?? ""}}</span>
                    </li>
                @empty
                @endforelse
                {{-- <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="textbox">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="fas fa-font"></i> <span>Textbox</span>
                </li>
                <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="textarea">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="far fa-envelope"></i> <span>Textarea</span>
                </li>
                <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="checkbox">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="far fa-check-square"></i> <span>Check Box</span>
                </li>
                <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="radio">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="far fa-dot-circle"></i> <span>Radio</span>
                </li>
                <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="drop-down">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="far fa-arrow-alt-circle-down"></i> <span>Drop Down</span>
                </li>
                <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="editor">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="fas fa-font"></i> <span>Ckeditor</span>
                </li>
                <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="button">
                    <i class="fas fa-ellipsis-v mr-10"></i><i class="fas fa-font"></i> <span>Button</span>
                </li> --}}
            </ul>
        </div>
        <div class="col-12 col-md-7">
            <input type="hidden" name="form_source_code" value="">
            <div id="form_data">
                <div class='card'>
                    <div class='card-header' contenteditable="true">Step 1 - Please enter your student's requested information</div>
                    <input type="hidden" name="form_id" id="form_id"> 
                    <div class='card-body input_container_builder' id="input_container_builder">
                        {{--<div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Student's Legal Last Name : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Date of Birth : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control mydatepicker01'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Race : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <select class='form-control custom-select'>
                                    <option value=''>Choose an option</option>
                                    <option value=''>Black/African American</option>
                                    <option value=''>White</option>
                                    <option value=''>Asian</option>
                                    <option value=''>Other</option>
                                </select>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Current School : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Current Year Grade : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <select class='form-control custom-select'>
                                    <option value=''>Choose an option</option>
                                    <option value=''>1</option>
                                    <option value=''>2</option>
                                    <option value=''>3</option>
                                    <option value=''>4</option>
                                    <option value=''>5</option>
                                    <option value=''>6</option>
                                    <option value=''>7</option>
                                    <option value=''>8</option>
                                </select>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Next Year Grade : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <select class='form-control custom-select'>
                                    <option value=''>Choose an option</option>
                                    <option value=''>1</option>
                                    <option value=''>2</option>
                                    <option value=''>3</option>
                                    <option value=''>4</option>
                                    <option value=''>5</option>
                                    <option value=''>6</option>
                                    <option value=''>7</option>
                                    <option value=''>8</option>
                                </select>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Home Address : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>City : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>ZIP : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Best Contact phone number : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Alternate phone number : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='text' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Parent Email address : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='email' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row'>
                            <label class='control-label col-12 col-md-5'>Confirm Email address : </label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <input type='email' class='form-control'>
                            </div>
                        </div>
                        <div class='form-group row' id="afsd">
                            <label class='control-label col-12 col-md-5'></label>
                            <div class='col-12 col-md-6 col-xl-6'>
                                <a href='javascript:void(0);' class='btn btn-secondary step-2-1-btn' title=''>Submit</a>
                            </div>
                        </div>--}}
                    </div>
                    <div class="text-center float-center">
                        <a class="btn btn-primary saveFormCreate"><i class="fa fa-sync"></i> Build</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-2">
            <div class="card p-5">
                <ul class="list-unstyled">
                    @forelse($formFields as $fld=>$formField)
                        <li class="field-type-list field-type-menu-item border mb-5 p-5" data-type="{{$formField->type}}" data-type-id="{{$formField->id}}" data-form-id="{{$form->id}}">
                            <i class="fas fa-ellipsis-v mr-10"></i><i class="{{$formField->icon ?? ""}}"></i> <span>{{$formField->name ?? ""}}</span>
                        </li>
                    @empty
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>