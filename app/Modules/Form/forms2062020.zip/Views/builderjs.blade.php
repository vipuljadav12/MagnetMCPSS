<script type="text/javascript">
	var inputJson = new Array();
	// console.log(inputJson);
	$(document).on("dblclick",".field-type-menu-item",function()
	{
		var fieldType = $(this).attr("data-type");
		var fieldID = $(this).attr("data-type-id");
		var form_id = $(this).attr("data-form-id");
		// alert(fieldType);
		$.ajax({
		  url: '{{url("admin/Form/getField")}}',
		  type: 'GET',
		  data: {
		 	type:fieldType,
		 	id:fieldID,
		 	form_id:form_id
		  },
		  success: function(data) {
		    $(document).find(".input_container_builder").append(data);
		  },
		});
	});
	$(document).on("click",".saveFormCreate",function()
	{
		var allInputs = $(document).find(".inputToSave").attr("data-name");
		var allInputsValues = new Array();
		$(document).find(".form-input-group").each(function(key)
		{
			if($(this).attr("data-type") == "text")
			{
				var currentInput = new Array();
				currentInput["label"] = $(this).find(".inputLabel").html();
				currentInput["placeholder"] = $(this).find(".placeholderInput").text();
				currentInput["type"] = $(this).find(".typeChangeInput").val();
				checkRequired= $(this).find(".inputCheckBoxRequired").prop("checked");
				currentInput["required"]  = checkRequired == true ? "y" : "n";
				
			}
			// allInputsValues.push(currentInput);
			allInputsValues[key] = currentInput;
			// allInputsValues[input_name] = $(this).html();
		});
		console.log(allInputsValues);
		var form_id = $(document).find("#form_id").val();
		$.ajax({
		  url: '{{url("admin/Form/saveBuild")}}',
		  type: 'post',
		  data: {
		 	_token:"{{csrf_token()}}",
		 	data:allInputsValues,
		 	form_id:form_id
		  },
		  success: function(data) {
		    $(document).find(".input_container_builder").append(data);
		  },
		});
		/*$(document).find(".inputToSave").each(function()
		{
			var input_name = $(this).attr("data-name");
			allVal[input_name] = $(this).html();
		});*/
		// console.log(allInputs);
	});
	$(document).on("input change",".placeholderInput",function()
	{
		$(this).parent().find(".inputText").attr("placeholder",$(this).html());
	});
	$(document).on("change",".typeChangeInput",function()
	{
		$(this).parent().find("input").attr("type",$(this).val());
	});
	
	$(document).on("focus",".inputToSave",function()
	{
		$(this).addClass("input-border");
	});
	$(document).on("focusout",".inputToSave",function()
	{
		$(this).removeClass("input-border");
	});
</script>