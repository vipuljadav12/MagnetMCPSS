<div class='form-group form-input-group row' form-id="{{$form_id}}"  data-type={{$field->type}}>
	<label class='control-label col-3 col-md-3 inputToSave inputLabel' contenteditable="true" data-name="label" >Label : </label>
	<div class='col-5 col-md-5 col-xl-5'>
		<input type='text' class='form-control inputText'>
		<span class="mt5 mb5"><strong>Placeholder: </strong><span class="inputToSave  placeholderInput" contenteditable="true"> select placeholder</span></span>
		<br>
		<strong>Type: </strong>
		<select class="form-control-sm typeChangeInput">
			<option value="text">Text</option>
			<option value="number">Number</option>
			<option value="email">Email</option>
			<option value="date">Date</option>
		</select>
	</div>
	{{-- <div class='col-5 col-md-5 col-xl-5'>
		<input type='text' class='form-control'>
	</div> --}}
	<div class='col-md-2'>
		<label>Required? <input type="checkbox" name="" class="form-control"></label>
	</div>
	<div class='col-md-1'>
		<span class='close'><i class='fa fa-window-close' aria-hidden='true'></i></span>
	</div>
</div>