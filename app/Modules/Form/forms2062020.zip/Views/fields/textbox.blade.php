<div class='form-group row'>
	<label class='control-label col-12 col-md-5 inputToSave' contenteditable="true" data-name="label" >Label : </label>
	<div class='col-12 col-md-6 col-xl-6'>
		<input type='text' class='form-control'>
	</div>
	<div class='col-md-1'>
		<span class='close'><i class='fa fa-window-close' aria-hidden='true'></i></span>
	</div>
</div>