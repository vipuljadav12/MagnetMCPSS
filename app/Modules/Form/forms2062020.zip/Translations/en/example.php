<?php 

return [
    'welcome' => 'Welcome, this is From module.'
];
