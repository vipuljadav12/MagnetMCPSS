<?php 

return [
    'welcome' => 'Welcome, this is Eligibility module.'
];
