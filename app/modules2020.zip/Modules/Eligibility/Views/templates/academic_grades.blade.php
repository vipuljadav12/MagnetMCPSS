@php 
    if(isset($eligibilityContent))
    {
        $content = json_decode($eligibilityContent->content) ?? null;
        // print_r($eligibilityContent->content);
    }
@endphp
<div class="form-group">
    <label class="control-label">Name of Academic Grades</label>
    <div class="">
		<input type="text" class="form-control" value="{{$eligibility->name ?? old('name')}}" name="name">
        @if($errors->first('name'))
            <div class="mb-1 text-danger">
                {{-- {{ $errors->first('name')}} --}}
                Name is required.
            </div>
        @endif
	</div>
</div>
<div class="form-group">
    <label class="control-label">How are academic grades reported?</label>
    <div class="">
		<select class="form-control custom-select" name="extra[academic_grade]">
            @php 
                $grades = array(
                    "STD"=>"Standard Based",
                    "NUM"=>"1-100"
                );//array ends
            @endphp
            <option value="">Select Option</option>
            @foreach($grades as $g=>$grade)
                <option value="{{$g}}" @if(isset($content->academic_grade) && $content->academic_grade == $g) selected @endif>{{$grade}}</option>
            @endforeach
        </select>
	</div>
</div>
<div class="form-group">
    <label class="control-label">What academic terms will be used?</label>
    <div class="">
		<select class="form-control custom-select" name="extra[academic_term]">
            @php 
                $terms = array(
                    "SEM"=>"Semesters",
                    "9W"=>"9 weeks",
                    "YE"=>"Year End"
                );//array ends
            @endphp
            <option value="">Select Option</option>
            @foreach($terms as $t=>$term)
                <option value="{{$t}}" @if(isset($content->academic_term) && $content->academic_term == $t) selected @endif>{{$term}}</option>
            @endforeach
        </select>
	</div>
</div>
<div class="form-group">
    <label class="control-label">What course types will be used?</label>
    <div class="d-flex flex-wrap">
        @php 
            $subjects = array("re"=>"Reading","eng"=>"English","math"=>"Math","sci"=>"Science","ss"=>"Social Studies","o"=>"other");
        @endphp
        @foreach($subjects as $s=>$subject)
            <div class="mr-20">
                <div class="custom-control custom-checkbox">
                    <input  value="{{$s}}" type="checkbox" class="custom-control-input" id="checkbox{{$s}}" name="extra[subjects][]" @if(isset($content->subjects) && in_array($s, $content->subjects)) checked @endif >
                    <label for="checkbox{{$s}}" class="custom-control-label">{{$subject}}</label></div>
            </div>
        @endforeach        
    </div>
</div>
<div class="form-group">
    <label class="control-label">How many academic terms will be pulled?</label>
	<div class="d-flex flex-wrap">
        @for($i = 1 ; $i <= 4 ; $i++)
            <div class="mr-20">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="checkbox_terms_{{$i}}" value="{{$i}}" name="extra[terms_pulled][]" @if(isset($content->terms_pulled) && in_array($i, $content->terms_pulled)) checked @endif>
                <label for="checkbox_terms_{{$i}}" class="custom-control-label">{{$i}}</label></div>
            </div>
        @endfor
    </div>
</div>