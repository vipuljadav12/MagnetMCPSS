<?php

Route::group([ 'prefix'=>'admin/Eligibility','module' => 'Eligibility', 'middleware' => ['web','auth'], 'namespace' => 'App\Modules\Eligibility\Controllers'], function() {

    Route::get('/', 'EligibilityController@index');
    Route::get('/create', 'EligibilityController@create');
    Route::get('/getTemplateHtml/{id}', 'EligibilityController@getTemplateHtml');
   Route::post('/store', 'EligibilityController@store');
    Route::get('/edit/{eligibility}', 'EligibilityController@edit');
    Route::post('/update/{id}', 'EligibilityController@update');
    Route::get('/delete/{id}', 'EligibilityController@delete');
    Route::get('/trash', 'EligibilityController@trash');
    Route::get('/restore/{id}', 'EligibilityController@restore');
    Route::get('/view/{id}', 'EligibilityController@eligibilityView');
    Route::get('/status', 'EligibilityController@status');

});
