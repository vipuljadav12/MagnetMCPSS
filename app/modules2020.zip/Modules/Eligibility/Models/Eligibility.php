<?php

namespace App\Modules\Eligibility\Models;

use Illuminate\Database\Eloquent\Model;

class Eligibility extends Model {

    //
    protected $table='eligibiility';
    protected $primaryKey='id';
    protected $fillable=[
    	'template_id',
      	'name',
      	'type',
      	'district_id',
      	'store_for',
      	'status'
      	// 'created_at',
      	// 'updated_at',
    ];

}
