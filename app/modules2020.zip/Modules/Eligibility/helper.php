<?php

/**
 *	Eligibility Helper  
 */