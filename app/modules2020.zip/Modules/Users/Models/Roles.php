<?php

namespace App\Modules\Users\Models;

use Illuminate\Database\Eloquent\Model;

class Roles extends Model 
{
	protected $table = "role";

	public function getNameAttribute($value)
    {
        return ucwords($value);
    }
}
