<?php

namespace App\Modules\Users\Models;

use Illuminate\Database\Eloquent\Model;

class Users extends Model {

    //

}
