<?php 

return [
    'welcome' => 'Welcome, this is District module.'
];
