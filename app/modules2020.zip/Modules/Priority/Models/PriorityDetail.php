<?php

namespace App\Modules\Priority\Models;

use Illuminate\Database\Eloquent\Model;

class PriorityDetail extends Model {

    protected $fillable = [
    	'priority_id', 'name', 'description', 'sibling', 'majority_race_in_home_zone_school', 'current_enrollment_at_another_magnet_school','sort',
    ];

}
