<?php

/**
 *	Priority Helper  
 */