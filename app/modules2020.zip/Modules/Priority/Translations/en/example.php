<?php 

return [
    'welcome' => 'Welcome, this is Priority module.'
];
