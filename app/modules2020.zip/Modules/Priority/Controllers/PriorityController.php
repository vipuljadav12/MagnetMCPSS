<?php

namespace App\Modules\Priority\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\Priority\Models\Priority;
use App\Modules\Priority\Models\PriorityDetail;
use App\Modules\District\Models\District;
use Session;
// use Illuminate\Support\Facades\DB;

class PriorityController extends Controller
{

    public function __construct(){
        session()->put('district_id', 1);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $priorities = Priority::where('district_id', session('district_id'))
            ->where('status', '!=', 'T')
            ->get();
        return view('Priority::index', compact('priorities'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $district = District::where('id', Session("district_id"))->first(['desegregation_compliance']);
        $desegregation_compliance_status = $district->desegregation_compliance;
        return view('Priority::create', compact('desegregation_compliance_status'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {       
//         return $request;
        $rules = [
            'name' => 'required|string|max:30|unique:priorities',
            'description.*' => 'required|string|max:50',
        ];
        $messages = [
            'name.required' => 'Priority name is required.',
            'description.*.required' => 'Description is required.',
        ];
        $this->validate($request, $rules, $messages);

        $priority = Priority::create([
            'district_id' => Session("district_id"),
            'name' => $request->name,
        ]);

        if(isset($priority)){
            $i=1;
            $priority_detail=array();

            $siblingKeys = array_keys($request->sibling);
            if(isset($request->majority_race_in_home_zone_school))
                    $majorKeys = array_keys($request->majority_race_in_home_zone_school);
            else
                $majorKeys = array();
            $enrolKeys = array_keys($request->current_enrollment_at_another_magnet_school);


            foreach($request->description as $key=>$val){
                $priority_detail = ['priority_id'=>$priority->id];
                if(isset($request->description[$i])){
                    $priority_detail['description'] = $request->description[$i];
                }
                else{
                    $priority_detail['description'] = '';
                }
                if(count($siblingKeys) > 0 && in_array($key, $siblingKeys))
                {
                    $priority_detail['sibling'] = 'Y';
                }
                else{
                    $priority_detail['sibling'] = 'N';
                }
                if(count($majorKeys) > 0 && in_array($key, $majorKeys))
                {
                    $priority_detail['majority_race_in_home_zone_school'] = 'Y';
                }
                else{
                    $priority_detail['majority_race_in_home_zone_school'] = 'N';
                }
                if(count($enrolKeys) > 0 && in_array($key, $enrolKeys))
                {
                    $priority_detail['current_enrollment_at_another_magnet_school'] = 'Y';
                
                }
                else{
                    $priority_detail['current_enrollment_at_another_magnet_school'] = 'N';
                }
                $priority_detail_store = PriorityDetail::create($priority_detail);
                $i++;
            } 
            session()->flash('success', 'Priority added successfully.'); 
        }
        else{
            session()->flash('error', 'Priority not added.');
        }
        // return redirect('admin/Priority/create');
        return redirect("admin/Priority");
    }

    /**
     * Check status of priority
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkPriorityStatus(Request $request)
    {
        $update_status = Priority::where('id', $request->id)->update(['status' => $request->status]);
        if(isset($update_status)){
            return 'true';
        } 
        return 'false';
    }

    /**
     * Check priority name presence
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkPriorityNamePresence(Request $request)
    {   
        $priority = Priority::where('name', $request->name)->first();
        if(!isset($priority)){
            return 'true';
        } 
        elseif(isset($request->id) && $priority->id==$request->id){
            return 'true';
        }
        return 'false'; 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $priority = Priority::where('id', $id)
            ->where('district_id', Session("district_id"))
            ->first();
        $priority_details = PriorityDetail::where('priority_id', $id)->get();
        $district = District::where('id', Session("district_id"))->first(['desegregation_compliance']);
        $desegregation_compliance_status = $district->desegregation_compliance;
        return view('Priority::edit', compact('desegregation_compliance_status', 'priority', 'priority_details', 'id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {   
        $rules = [
            'name' => 'required|string|max:30|unique:priorities,name,'.$request->id,
            'description.*' => 'required|string|max:50',
        ];
        $messages = [
            'name.required' => 'Priority name is required.',
            'description.*.required' => 'Description is required.',
        ];
        $this->validate($request, $rules, $messages);

        $priority = Priority::where('id', $request->id)
            ->update([
                'name' => $request->name,
            ]);

        if(isset($priority)){
            $priority_id = ['priority_id'=>$request->id];
            $i=1;
            $priority_detail=array();

            $siblingKeys = array_keys($request->sibling);
            if(isset($request->majority_race_in_home_zone_school))
                    $majorKeys = array_keys($request->majority_race_in_home_zone_school);
            else
                $majorKeys = array();
            $enrolKeys = array_keys($request->current_enrollment_at_another_magnet_school);



            foreach($request->description as $key=>$val){                
                $id = ['id'=>$request->priority_detail_id[$i]];
                if(isset($request->description[$i])){
                    $priority_detail['description'] = $request->description[$i];
                }
                else{
                    $priority_detail['description'] = '';
                }

                if(count($siblingKeys) > 0 && in_array($key, $siblingKeys))
                {
                    $priority_detail['sibling'] = 'Y';
                }
                else{
                    $priority_detail['sibling'] = 'N';
                }
                if(count($majorKeys) > 0 && in_array($key, $majorKeys))
                {
                    $priority_detail['majority_race_in_home_zone_school'] = 'Y';
                }
                else{
                    $priority_detail['majority_race_in_home_zone_school'] = 'N';
                }
                if(count($enrolKeys) > 0 && in_array($key, $enrolKeys))
                {
                    $priority_detail['current_enrollment_at_another_magnet_school'] = 'Y';
                
                }
                else{
                    $priority_detail['current_enrollment_at_another_magnet_school'] = 'N';
                }

                $priority_detail_update = PriorityDetail::where('id', $id)
                    ->where('priority_id', $priority_id)
                    ->update($priority_detail);
                $i++;
            }  
            session()->flash('success', 'Priority updated successfully.');
        }
        else{
            session()->flash('error', 'Priority not updated.');
        }
        return redirect()->back();
        // return redirect('Priority/add');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {   
        $priority_status = Priority::where('id', $id)
            ->update(['status' => 'T']);
        if(isset($priority_status)){
            session()->flash('success', "Priority deleted successfully"); 
        }
        else{
            session()->flash('error', "Priority not deleted");
        }
        return redirect('admin/Priority');
        // $delete_priority_detail = PriorityDetail::where('priority_id', $id)
        //     ->delete();
        // if(isset($delete_priority_detail)){
        //     $delete_priority = Priority::where('id', $id)
        //     ->delete();
        //     if(isset($delete_priority)){
        //         session()->flash('success', "Priority deleted successfully");
        //     }    
        // }
        // else{
        //     session()->flash('error', "Priority not deleted");
        // }
        // return redirect('admin/Priority');
    }

    /**
     * Display a listing of the trashed resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showTrash()
    {   
        $priorities = Priority::where('district_id', session('district_id'))
            ->where('status', 'T')
            ->get();
        return view('Priority::trash', compact('priorities'));
    }

    /**
     * Restore from trash.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restoreFromTrash($id)
    {   
        $priority_status = Priority::where('id', $id)
            ->update(['status' => 'Y']);
        if(isset($priority_status)){
            session()->flash('success', "Priority restored successfully"); 
        }
        else{
            session()->flash('error', "Priority not restored");
        }
        return redirect('admin/Priority/trash');
    }
}
