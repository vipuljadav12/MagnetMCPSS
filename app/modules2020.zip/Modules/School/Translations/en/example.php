<?php 

return [
    'welcome' => 'Welcome, this is School module.'
];
