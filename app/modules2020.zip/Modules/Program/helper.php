<?php

/**
 *	Program Helper  
 */