<?php 

return [
    'welcome' => 'Welcome, this is Program module.'
];
