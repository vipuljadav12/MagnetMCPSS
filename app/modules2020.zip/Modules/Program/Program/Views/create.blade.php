@extends('layouts.admin.app')
@section('title')Add Program  | {{config('APP_NAME',env("APP_NAME"))}}  @endsection
@section('styles')
    <style>
        input[type="checkbox"].styled-checkbox + label.label-xs {padding-left: 1.5rem;}
        .tooltip1 {
            position: relative;
            display: inline-block;
        }
        .tooltip1 .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: black;
            color: #fff;
            text-align: center;
            padding: 5px 0;
            border-radius: 6px;
            position: absolute;
            z-index: 1;
            margin-left: -60px;
            bottom: 115%;
            left: 50%;
        }
        .tooltip1:hover .tooltiptext {
            visibility: visible;
        }
        .tooltip1 .tooltiptext::after {
            content: " ";
            position: absolute;
            top: 100%; /* At the bottom of the tooltip */
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: black transparent transparent transparent;
        }
        .tooltip1 .tooltiptext-btm {top: 115%; bottom: auto;}
        .tooltip1 .tooltiptext-btm::after {
            content: "";
            position: absolute;
            top: -9px;
            bottom: auto;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent black transparent;
        }
    </style>
@endsection
@section('content')
    <div class="card shadow">
        <div class="card-body d-flex align-items-center justify-content-between flex-wrap">
            <div class="page-title mt-5 mb-5">Add Program</div>
            <div class=""><a href="{{url('admin/Program')}}" class="btn btn-sm btn-secondary" title="">Back</a></div>
        </div>
    </div>
    <form action="{{url('admin/Program/store')}}" method="post" class="">
        {{csrf_field()}}
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item"><a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">General</a></li>
            <li class="nav-item"><a class="nav-link" id="eligibility-tab" data-toggle="tab" href="#eligibility" role="tab" aria-controls="eligibility" aria-selected="false">Eligibility</a></li>
            <!--<li class="nav-item"><a class="nav-link" id="config-tab" data-toggle="tab" href="#config" role="tab" aria-controls="config" aria-selected="false">Configurations</a></li>-->
            <li class="nav-item"><a class="nav-link" id="process-tab" data-toggle="tab" href="#process" role="tab" aria-controls="process" aria-selected="false">Selection</a></li>
            <!--<li class="nav-item"><a class="nav-link" id="recommendation-tab" data-toggle="tab" href="#recommendation" role="tab" aria-controls="recommendation" aria-selected="true">Add Recommendation</a></li>-->
        </ul>
        <div class="tab-content bordered" id="myTabContent">
            <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Program Set Up</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label">Program Name : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="name" value="{{old('name')}}">
                                        </div>
                                        @if($errors->first('name'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('name')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Applicant Group Filter 1 : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="applicant_filter1" value="{{old('applicant_filter1')}}">
                                        </div>
                                        @if($errors->first('applicant_filter1'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('applicant_filter1')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Applicant Group Filter 2 : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="applicant_filter2" value="{{old('applicant_filter2')}}">
                                        </div>
                                        @if($errors->first('applicant_filter2'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('applicant_filter2')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Applicant Group Filter 3 : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="applicant_filter3" value="{{old('applicant_filter3')}}">
                                        </div>
                                        @if($errors->first('applicant_filter3'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('applicant_filter3')}}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>
                                        <div class="row flex-wrap">
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="PreK" class="custom-control-input" id="table25">
                                                    <label for="table25" class="custom-control-label">PreK</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="K" class="custom-control-input" id="table06">
                                                    <label for="table06" class="custom-control-label">K</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="1" class="custom-control-input" id="table07">
                                                    <label for="table07" class="custom-control-label">1</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="2" class="custom-control-input" id="table08">
                                                    <label for="table08" class="custom-control-label">2</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="3" class="custom-control-input" id="table09">
                                                    <label for="table09" class="custom-control-label">3</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="4" class="custom-control-input" id="table10">
                                                    <label for="table10" class="custom-control-label">4</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="5" class="custom-control-input" id="table11">
                                                    <label for="table11" class="custom-control-label">5</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="6" class="custom-control-input" id="table12">
                                                    <label for="table12" class="custom-control-label">6</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="7" class="custom-control-input" id="table13">
                                                    <label for="table13" class="custom-control-label">7</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="8" class="custom-control-input" id="table14">
                                                    <label for="table14" class="custom-control-label">8</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="9" class="custom-control-input" id="table15">
                                                    <label for="table15" class="custom-control-label">9</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="10" class="custom-control-input" id="table16">
                                                    <label for="table16" class="custom-control-label">10</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="11" class="custom-control-input" id="table17">
                                                    <label for="table17" class="custom-control-label">11</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="12" class="custom-control-input" id="table18">
                                                    <label for="table18" class="custom-control-label">12</label></div>
                                            </div>
                                        </div>
                                        @if($errors->first('grade_lavel'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('grade_lavel')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label"><strong>Parent Submission Form :</strong> </label>
                                        <div class="">
                                            <select class="form-control custom-select" name="parent_submission_form">
                                                <option value="">Choose an Option</option>
                                                {{--<option value="HCS Basic Magnet">HCS Basic Magnet</option>
                                                <option value="HCS College Academy">HCS College Academy</option>
                                                <option value="HCS AGT">HCS AGT</option>
                                                <option value="TCS Specialty Form">TCS Specialty Form</option>--}}
                                                <option value="MCPSS Magnet Form">MCPSS Magnet Form</option>
                                                <option value="MPS Magnet Form">MPS Magnet Form </option>
                                            </select>
                                        </div>
                                        @if($errors->first('parent_submission_form'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('parent_submission_form')}}
                                            </div>
                                        @endif
                                        {{-- <!--<div class="row flex-wrap">
                                                 <div class="col-12 col-sm-4">
                                                     <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table00" checked>
                                                     <label for="table00" class="custom-control-label">HCS Basic Magnet</label></div>
                                                 </div>
                                                 <div class="col-12 col-sm-4">
                                                     <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table01">
                                                     <label for="table01" class="custom-control-label">HCS College Academy</label></div>
                                                 </div>
                                                 <div class="col-12 col-sm-4">
                                                     <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table02">
                                                     <label for="table02" class="custom-control-label">HCS AGT</label></div>
                                                 </div>
                                                 <div class="col-12 col-sm-4">
                                                     <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table03">
                                                     <label for="table03" class="custom-control-label">TCS Specialty Form</label></div>
                                                 </div>
                                                 <div class="col-12 col-sm-4">
                                                     <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table04">
                                                     <label for="table04" class="custom-control-label">MCPSS Magnet Form</label></div>
                                                 </div>
                                                 <div class="col-12 col-sm-4">
                                                     <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table05">
                                                     <label for="table05" class="custom-control-label">MPS Magnet Form </label></div>
                                                 </div>
                                             </div>-->--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Priority Set Up</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Select Priority :</strong> </label>
                                        <div class="d-flex flex-wrap">
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="none" class="custom-control-input" id="table28">
                                                    <label for="table28" class="custom-control-label">None</label></div>
                                            </div>
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="1" class="custom-control-input" id="table29">
                                                    <label for="table29" class="custom-control-label">1</label></div>
                                            </div>
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="2" class="custom-control-input" id="table30">
                                                    <label for="table30" class="custom-control-label">2</label></div>
                                            </div>
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="3" class="custom-control-input" id="table31">
                                                    <label for="table31" class="custom-control-label">3</label></div>
                                            </div>
                                        </div>
                                        @if($errors->first('priority'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('priority')}}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="tab-pane fade" id="eligibility" role="tabpanel" aria-labelledby="eligibility-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Basic</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_00" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_01" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Recommendation Form : </label>
                                        <div class=""><input id="chk_02" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Writing Prompt : </label>
                                        <div class=""><input id="chk_03" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Audition : </label>
                                        <div class=""><input id="chk_04" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_05" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Conduct : </label>
                                        <div class=""><input id="chk_06" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Spec Ed Indicator : </label>
                                        <div class=""><input id="chk_07" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Interview Score : </label>
                                        <div class=""><input id="chk_08" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Standardized Testing : </label>
                                        <div class=""><input id="chk_09" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Combined</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_10" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_11" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_12" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Additional</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_13" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_14" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Recommendation Form : </label>
                                        <div class=""><input id="chk_15" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Writing Prompt : </label>
                                        <div class=""><input id="chk_16" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Audition : </label>
                                        <div class=""><input id="chk_17" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_18" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Conduct : </label>
                                        <div class=""><input id="chk_19" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Spec Ed Indicator : </label>
                                        <div class=""><input id="chk_20" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Interview Score : </label>
                                        <div class=""><input id="chk_21" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Standardized Testing : </label>
                                        <div class=""><input id="chk_22" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Final</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_23" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_24" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_25" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            <div class="tab-pane fade" id="eligibility" role="tabpanel" aria-labelledby="eligibility-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header d-flex flex-wrap justify-content-between">
                            <div class="">Eligibility Determination Method</div>
                            <!--<div class=""><a href="add-eligibility-master.html" class="btn btn-secondary btn-sm" title="">Add Recommendation Form Eligibility</a></div>-->
                        </div>
                        <div class="card-body">
                            <div class="pb-10 d-flex flex-wrap justify-content-center align-items-center">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="basic_method_only" type="checkbox" class="js-switch js-switch-1 js-switch-xs" name="basic_method_only"  data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="combined_scoring" type="checkbox" class="js-switch js-switch-1 js-switch-xs"  name="combined_scoring" data-size="Small" checked>
                                </div>
                                <!--<div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_2" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>-->
                                <div class="d-flex mb-10">
                                    <div class="mr-10 mt-5">Select Combined Eligibility : </div>
                                    <div class="">
                                        <select class="form-control custom-select" id="combined_eligibility" name="combined_eligibility">
                                            <option value="">Choose an Option</option>
                                            <option value="Sum Scores" {{old('combined_eligibility')=='Sum Scores'?'selected':''}}>Sum Scores</option>
                                            <option value="Average Scores" {{old('combined_eligibility')=='Average Scores'?'selected':''}}>Average Scores</option>
                                            <option value="Weighted Scores" {{old('combined_eligibility')=='Weighted Scores'?'selected':''}}>Weighted Scores</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                    <tr>
                                        <th class="align-middle">Eligibility Type</th>
                                        <th class="align-middle">Used in Determination Method</th>
                                        <th class="align-middle text-center">Eligibility Defined</th>
                                        <th class="align-middle text-center">Assigned Eligibility Name</th>
                                        <th class="align-middle text-center"><div class="tooltip1">Weight<span class="tooltiptext tooltiptext-btm">If combined and weighted is selected</span></div></th>
                                        <th class="align-middle text-center w-120">Active</th>
                                        <th class="align-middle text-center w-120">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @forelse($eligibilities as $key=>$eligibility)
                                        @if($eligibility->name=='Interview Score')
                                            <tr>
                                            <td class="">
                                                Interview Score
                                                <input type="hidden" name="eligibility_type[]" value="interview_score">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name=" assigned_eigibility_name[]">
                                                    <option value="Choose an Option" {{old('assigned_eigibility_name')=='Choose an Option'?'selected':''}}>Choose an Option</option>
                                                    <option value="Interview Score 1" {{old('assigned_eigibility_name')=='Interview Score 1'?'selected':''}}>Interview Score 1</option>
                                                    <option value="Interview Score 2" {{old('assigned_eigibility_name')=='Interview Score 2'?'selected':''}}>Interview Score 2</option>
                                                </select>
                                            </td>
                                            <td class="">
                                                <input type="text" name="weight[]" class="form-control" value="50%">
                                            </td>
                                            <td class="text-center">
                                                <input id="chk_00" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#modal_1" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a>
                                                <a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Grades')
                                            <tr>
                                            <td class="">
                                                Grades
                                                <input type="hidden" name="eligibility_type[]" value="grades">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="" >Choose an Option</option>
                                                    <option value="Grades 1" {{old('assigned_eigibility_name')=='Grades 1'?'selected':''}}>Grades 1</option>
                                                    <option value="Grades 2" {{old('assigned_eigibility_name')=='Grades 2'?'selected':''}}>Grades 2</option>
                                                </select>
                                            </td>
                                            <td class="">
                                                <input type="text" name="weight[]" class="form-control" value="50%">
                                            </td>
                                            <td class="text-center">
                                                <input id="chk_00" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#modal_2" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a>
                                                <a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Academic Grade Calculation')
                                            <tr>
                                            <td class="">
                                                Academic Grade Calculation
                                                <input type="hidden" name="eligibility_type[]" value="arcademic_grade">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Academic Grade 1" {{old('assigned_eigibility_name')=='Academic Grade 1'?'selected':''}}>Academic Grade 1</option>
                                                    <option value="Academic Grade 2" {{old('assigned_eigibility_name')=='Academic Grade 2'?'selected':''}}>Academic Grade 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control " value=""></td>
                                            <td class="text-center">
                                                <input id="chk_02" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                            </td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_3" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Recommendation Form')
                                            <tr>
                                            <td class="">
                                                Recommendation Form 1
                                                <input type="hidden" name="eligibility_type[]" value="recommendation_form1">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Recommendation Form 1" {{old('assigned_eigibility_name')=='Recommendation Form 1'?'selected':''}}>Recommendation Form 1</option>
                                                    <option value="Recommendation Form 2" {{old('assigned_eigibility_name')=='Recommendation Form 2'?'selected':''}}>Recommendation Form 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]"  class="form-control" value="25%"></td>
                                            <td class="text-center">
                                                <input id="chk_03" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#modal_4" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a>
                                                <a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Writing Prompt')
                                            <tr>
                                            <td class="">
                                                Writing Prompt
                                                <input type="hidden" name="eligibility_type[]" value="writing_prompt">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Writing Prompt 1" {{old('assigned_eigibility_name')=='Writing Prompt 1'?'selected':''}} >Writing Prompt 1</option>
                                                    <option value="Writing Prompt 2" {{old('assigned_eigibility_name')=='Writing Prompt 2'?'selected':''}}>Writing Prompt 2</option>
                                                </select>
                                            </td>
                                            <td class="">
                                                <input type="text" name="weight[]" class="form-control" value="50%">
                                            </td>
                                            <td class="text-center"><input id="chk_04" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_5" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Audition')
                                            <tr>
                                            <td class="">
                                                Audition
                                                <input type="hidden" name="eligibility_type[]" value="audition">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Audition 1" {{old('assigned_eigibility_name')=='Audition 1'?'selected':''}}>Audition 1</option>
                                                    <option value="Audition 2" {{old('assigned_eigibility_name')=='Audition 2'?'selected':''}}>Audition 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control" value=""></td>
                                            <td class="text-center"><input id="chk_05" name="status[]" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_6" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Committee Score')
                                            <tr>
                                            <td class="">
                                                Committee Score
                                                <input type="hidden" name="eligibility_type[]" value="committee_score">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/close.png" alt="Not Applicable"><span class="tooltiptext">Not Applicable</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Committee Score 1" {{old('assigned_eigibility_name')=='Committee Score 1'?'selected':''}}>Committee Score 1</option>
                                                    <option value="Committee Score 2" {{old('assigned_eigibility_name')=='Committee Score 2'?'selected':''}}>Committee Score 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control" value=""></td>
                                            <td class="text-center"><input id="chk_06" name="status[]" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_7" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Conduct Disciplinary Info')
                                            <tr>
                                            <td class="">
                                                Conduct Disciplinary Info
                                                <input type="hidden" name="eligibility_type[]" value="conduct_disciplinary_info">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Conduct Disciplinary Info 1" {{old('assigned_eigibility_name')=='Conduct Disciplinary Info 1'?'selected':''}} >Conduct Disciplinary Info 1</option>
                                                    <option value="Conduct Disciplinary Info 2" {{old('assigned_eigibility_name')=='Conduct Disciplinary Info 2'?'selected':''}}>Conduct Disciplinary Info 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control" value=""></td>
                                            <td class="text-center"><input id="chk_07" name="status[]" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_8" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Special Ed Indicators')
                                            <tr>
                                            <td class="">
                                                Special Ed Indicators
                                                <input type="hidden" name="eligibility_type[]" value="special_ed_indicators">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/close.png" alt="Not Applicable"><span class="tooltiptext">Not Applicable</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Special Ed Indicator 1" {{old('assigned_eigibility_name')=='Special Ed Indicator 1'?'selected':''}}>Special Ed Indicator 1</option>
                                                    <option value="Special Ed Indicator 2" {{old('assigned_eigibility_name')=='Special Ed Indicator 2'?'selected':''}}>Special Ed Indicator 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control" value=""></td>
                                            <td class="text-center"><input id="chk_08" name="status[]" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_9" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        @if($eligibility->name=='Standardized Testing')
                                            <tr>
                                            <td class="">
                                                Standardized Testing
                                                <input type="hidden" name="eligibility_type[]" value="standardized_testing">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/close.png" alt="Not Applicable"><span class="tooltiptext">Not Applicable</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Standardized Testing 1" {{old('assigned_eigibility_name')=='Standardized Testing 1'?'selected':''}}>Standardized Testing 1</option>
                                                    <option value="Standardized Testing 2" {{old('assigned_eigibility_name')=='Standardized Testing 2'?'selected':''}}>Standardized Testing 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control" value=""></td>
                                            <td class="text-center"><input id="chk_09" name="status[]" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_10" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>
                                        @endif
                                        {{--<tr>
                                            <td class="">
                                                Recommendation Form 2
                                                <input type="hidden" name="eligibility_type[]" value="recommendation_form2">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name="assigned_eigibility_name[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Recommendation Form 1" {{old('assigned_eigibility_name')=='Recommendation Form 1'?'selected':''}}>Recommendation Form 1</option>
                                                    <option value="Recommendation Form 2" {{old('assigned_eigibility_name')=='Recommendation Form 2'?'selected':''}}>Recommendation Form 2</option>
                                                </select>
                                            </td>
                                            <td class=""><input type="text" name="weight[]" class="form-control" value=""></td>
                                            <td class="text-center"><input id="chk_10" name="status[]" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                            <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_11" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                        </tr>--}}
                                        @empty
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="tab-pane fade" id="config" role="tabpanel" aria-labelledby="config-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Writing Prompt</div>
                        <div class="card-body">
                            <div class="">
                                <div class="form-group row">
                                    <label class="control-label col-12 col-md-12">Writing Prompt</label>
                                    <div class="col-12 col-md-12">
                                        <input type="text" class="form-control" value="In the College Academy students are required to complete rigorous high school and college courses. Students will work with a diverse group of peers who are interested in a wide variety">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            <div class="tab-pane fade" id="process" role="tabpanel" aria-labelledby="process-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Selection Process Set Up</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-12">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Ranking System :</strong> </label>
                                        <div class="row flex-wrap">
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Committee Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="committee_score" id="committee_score">
                                                        <option value="">NA</option>
                                                        <option class="1" value="1" {{old('committee_score')=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{old('committee_score')=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{old('committee_score')=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{old('committee_score')=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{old('committee_score')=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{old('committee_score')=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Priority : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="rating_priority" id="rating_priority">
                                                        <option value="">NA</option>
                                                        <option value="1" {{old('rating_priority')=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{old('rating_priority')=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{old('rating_priority')=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{old('rating_priority')=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{old('rating_priority')=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{old('rating_priority')=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Lottery Number : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="lottery_number" id="lottery_number">
                                                        <option value="">NA</option>
                                                        <option value="1" {{old('lottery_number')=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{old('lottery_number')=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{old('lottery_number')=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{old('lottery_number')=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{old('lottery_number')=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{old('lottery_number')=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Combined Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="combine_score" id="combine_score">
                                                        <option value="">NA</option>
                                                        <option value="1" {{old('combine_score')=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{old('combine_score')=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{old('combine_score')=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{old('combine_score')=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{old('combine_score')=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{old('combine_score')=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Audition Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="audition_score" id="audition_score">
                                                        <option value="">NA</option>
                                                        <option value="1" {{old('audition_score')=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{old('audition_score')=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{old('audition_score')=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{old('audition_score')=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{old('audition_score')=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{old('audition_score')=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Final Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="final_score" id="final_score">audition_scorefinal_score
                                                        <option value="">NA</option>
                                                        <option value="1" {{old('final_score')=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{old('final_score')=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{old('final_score')=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{old('final_score')=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{old('final_score')=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{old('final_score')=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-12">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Selection Method :</strong> </label>
                                        <div class="row flex-wrap">
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-radio"><input type="radio" name="selection_method" value="Racial Composition" class="custom-control-input" id="table27">
                                                    <label for="table27" class="custom-control-label">Racial Composition</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-radio"><input type="radio" name="selection_method"  value="Home Zone Placement" class="custom-control-input" id="table23">
                                                    <label for="table23" class="custom-control-label">Home Zone Placement</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-radio"><input type="radio" name="selection_method" value="Lottery Number Only" class="custom-control-input" id="table24">
                                                    <label for="table24" class="custom-control-label">Lottery Number Only</label></div>
                                            </div>
                                        </div>
                                        @if($errors->first('selection_method'))
                                            <div class="mb-1 text-danger">
                                                {{$errors->first('selection_method')}}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-12 col-lg-12">
                                    <div class="row flex-wrap">
                                        <div class="col-12  form-group">
                                            <label for="table26" class="mr-10"><strong>Selection By : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="selection_by" >
                                                    <option value="">Select</option>
                                                    <option value="Program Name" {{old('selection_by')=='Program Name'?'selected':''}}>Program Name</option>
                                                    <option value="Application Filter 1" {{old('selection_by')=='Application Filter 1'?'selected':''}}>Application Filter 1</option>
                                                    <option value="Application Filter 2" {{old('selection_by')=='Application Filter 2'?'selected':''}}>Application Filter 2</option>
                                                    <option value="Application Filter 3" {{old('selection_by')=='Application Filter 3'?'selected':''}}>Application Filter 3</option>
                                                </select>
                                            </div>
                                            @if($errors->first('selection_by'))
                                                <div class="mb-1 text-danger">
                                                    {{ $errors->first('selection_by')}}
                                                </div>
                                            @endif
                                        </div>
                                        {{--<div class="col-12 form-group d-none" id="home_zone_sel">
                                            <label for="table26" class="mr-10"><strong>Selection By : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="selection_by[]" >
                                                    <option value="">Select</option>
                                                    <option value="Program Name" {{old('selection_by')=='Program Name'?'selected':''}}>Program Name</option>
                                                    <option value="Application Filter 1" {{old('selection_by')=='Application Filter 1'?'selected':''}}>Application Filter 1</option>
                                                    <option value="Application Filter 2" {{old('selection_by')=='Application Filter 2'?'selected':''}}>Application Filter 2</option>
                                                    <option value="Application Filter 3" {{old('selection_by')=='Application Filter 3'?'selected':''}}>Application Filter 3</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 form-group d-none" id="Lottery_num_sel">
                                            <label for="table26" class="mr-10"><strong>Selection By : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="selection_by[]" >
                                                    <option value="">Select</option>
                                                    <option value="Program Name" {{old('selection_by')=='Program Name'?'selected':''}}>Program Name</option>
                                                    <option value="Application Filter 1" {{old('selection_by')=='Application Filter 1'?'selected':''}}>Application Filter 1</option>
                                                    <option value="Application Filter 2" {{old('selection_by')=='Application Filter 2'?'selected':''}}>Application Filter 2</option>
                                                    <option value="Application Filter 3" {{old('selection_by')=='Application Filter 3'?'selected':''}}>Application Filter 3</option>
                                                </select>
                                            </div>
                                        </div>--}}
                                        <div class="col-12 form-group " >
                                            <label for="table26" class="mr-10"><strong>Seat Availability Entered by : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="seat_availability_enter_by" id="seat_availability_enter_by">
                                                    <option value="">Select</option>
                                                    <option value="Manual Entry" {{old('seat_availability')=='Manual Entry'?'selected':''}}>Manual Entry</option>
                                                    <option value="Calculation" {{old('seat_availability')=='Calculation'?'selected':''}}>Calculation</option>
                                                </select>
                                            </div>
                                            @if($errors->first('seat_availability_enter_by'))
                                                <div class="mb-1 text-danger">
                                                    {{ $errors->first('seat_availability_enter_by')}}
                                                </div>
                                            @endif
                                        </div>
                                        {{--<div class="col-12 form-group d-none" id="home_zone_seat">
                                            <label for="table26" class="mr-10"><strong>Seat Availability Entered by : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="seat_availability" >
                                                    <option value="">Select</option>
--}}{{--                                                    <option value="Manual Entry" {{old('seat_availability')=='Manual Entry'?'selected':''}}>Manual Entry</option>--}}{{--
                                                    <option value="Calculation" {{old('seat_availability')=='Calculation'?'selected':''}}>Calculation</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 form-group d-none" id="Lottery_num_seat">
                                            <label for="table26" class="mr-10"><strong>Seat Availability Entered by : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="seat_availability">
                                                    <option value="">Select</option>
--}}{{--                                                    <option value="Manual Entry" {{old('seat_availability')=='Manual Entry'?'selected':''}}>Manual Entry</option>--}}{{--
                                                    <option value="Calculation" {{old('seat_availability')=='Calculation'?'selected':''}}>Calculation</option>
                                                </select>
                                            </div>
                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="tab-pane fade" id="recommendation" role="tabpanel" aria-labelledby="recommendation-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Recommendation Form</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label">Eligibility Name : </label>
                                <div class=""><input type="text" class="form-control" value=""></div>
                            </div>
                            <div class="form-group text-right"><a href="javascript:void(0);" class="btn btn-secondary btn-sm add-header" title="">Add Header</a></div>
                            <div class="form-list"></div>
                        </div>
                    </div>
                </div>
            </div>-->
        </div>
        <div class="box content-header-floating" id="listFoot">
            <div class="row">
                <div class="col-lg-12 text-right hidden-xs float-right">
                    <button type="submit" class="btn btn-warning btn-xs"><i class="fa fa-save"></i> Save </button>
                    <button type="submit" class="btn btn-success btn-xs" name="save_edit" value="save_edit"><i class="fa fa-save" ></i> Save &amp; Edit</button>
                </div>
            </div>
        </div>

    <!-- Modal -->
    <div class="modal fade" id="modal_1" tabindex="-1" role="dialog" aria-labelledby="modal_1Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_1Label">Edit Eligibility - Interview Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Interview Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[interview_score][]" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Interview Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_2" tabindex="-1" role="dialog" aria-labelledby="modal_2Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_2Label">Edit Eligibility - Grades Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Grade Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table46" checked>
                                                <label for="table46" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table47">
                                                <label for="table47" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table48">
                                                <label for="table48" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table49">
                                                <label for="table49" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table50">
                                                <label for="table50" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table51">
                                                <label for="table51" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table52">
                                                <label for="table52" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table53">
                                                <label for="table53" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table54">
                                                <label for="table54" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table55">
                                                <label for="table55" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2" >
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table59">
                                                <label for="table59" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table56">
                                                <label for="table56" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table57">
                                                <label for="table57" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[grades][]" class="custom-control-input" id="table58">
                                                <label for="table58" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Grades Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_3" tabindex="-1" role="dialog" aria-labelledby="modal_3Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_3Label">Edit Eligibility - Academic Grade Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Academic Grade Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[arcademic_grade][]"  class="custom-control-input" id="table60" checked>
                                                <label for="table60" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox"value="K" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table61">
                                                <label for="table61" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table62">
                                                <label for="table62" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table63">
                                                <label for="table63" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table64">
                                                <label for="table64" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table65">
                                                <label for="table65" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table66">
                                                <label for="table66" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table67">
                                                <label for="table67" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table68">
                                                <label for="table68" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table69">
                                                <label for="table69" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table70">
                                                <label for="table70" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table71">
                                                <label for="table71" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table72">
                                                <label for="table72" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[arcademic_grade][]" class="custom-control-input" id="table73">
                                                <label for="table73" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Academic Grade Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_4" tabindex="-1" role="dialog" aria-labelledby="modal_4Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_4Label">Edit Eligibility - Recommendation Form 1</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="">
                                <div class="form-group">
                                    <label class="control-label">Select Prior Developed Recommendation Form: : </label>
                                    <div class="">
                                        <select class="form-control custom-select" name="eligibility_grade_lavel[recommendation_form1][]">
                                            <option value="HCS STEM Teacher Recommendation">HCS STEM Teacher Recommendation</option>
                                            <option value="HCS Principal Recommendation">HCS Principal Recommendation</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_5" tabindex="-1" role="dialog" aria-labelledby="modal_5Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_5Label">Edit Eligibility - Writing Prompt Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Writing Prompt Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table74" checked>
                                                <label for="table74" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table75">
                                                <label for="table75" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table76">
                                                <label for="table76" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table77">
                                                <label for="table77" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox"value="3" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table78">
                                                <label for="table78" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table79">
                                                <label for="table79" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table80">
                                                <label for="table80" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table81">
                                                <label for="table81" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table82">
                                                <label for="table82" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table83">
                                                <label for="table83" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table84">
                                                <label for="table84" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table85">
                                                <label for="table85" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table86">
                                                <label for="table86" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[writing_prompt][]" class="custom-control-input" id="table87">
                                                <label for="table87" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Writing Prompt Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                    <div class="form-group d-flex flex-wrap">
                                        <div class="mr-10">None / Display Only : </div>
                                        <input id="chk_9" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_6" tabindex="-1" role="dialog" aria-labelledby="modal_6Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_6Label">Edit Eligibility - Audition Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Audition Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[audition][]" id="table89" class="custom-control-input" checked>
                                                <label for="table89" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[audition][]" id="table90" class="custom-control-input">
                                                <label for="table90" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[audition][]" id="table91" class="custom-control-input" >
                                                <label for="table91" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[audition][]" id="table92" class="custom-control-input" >
                                                <label for="table92" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[audition][]" id="table93" class="custom-control-input">
                                                <label for="table93" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[audition][]" id="table95" class="custom-control-input" >
                                                <label for="table95" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox"  value="5" name="eligibility_grade_lavel[audition][]" id="table96" class="custom-control-input">
                                                <label for="table96" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[audition][]" id="table97" class="custom-control-input">
                                                <label for="table97" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[audition][]" id="table98" class="custom-control-input">
                                                <label for="table98" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[audition][]" id="table99" class="custom-control-input" >
                                                <label for="table99" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[audition][]" id="table100" class="custom-control-input">
                                                <label for="table100" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[audition][]" id="table101" class="custom-control-input" >
                                                <label for="table101" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[audition][]" id="table102" class="custom-control-input">
                                                <label for="table102" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[audition][]" id="table103" class="custom-control-input">
                                                <label for="table103" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Audition Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_7" tabindex="-1" role="dialog" aria-labelledby="modal_7Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_7Label">Edit Eligibility - Committee Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Committee Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" value="PreK" name="eligibility_grade_lavel[committee_score][]" id="table104" checked>
                                                <label for="table104" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table105">
                                                <label for="table105" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table106">
                                                <label for="table106" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table107">
                                                <label for="table107" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table108">
                                                <label for="table108" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table109">
                                                <label for="table109" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table110">
                                                <label for="table110" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table111">
                                                <label for="table111" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table112">
                                                <label for="table112" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table113">
                                                <label for="table113" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table114">
                                                <label for="table114" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table115">
                                                <label for="table115" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table116">
                                                <label for="table116" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[committee_score][]" class="custom-control-input" id="table117">
                                                <label for="table117" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Committee Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_8" tabindex="-1" role="dialog" aria-labelledby="modal_8Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_8Label">Edit Eligibility - Conduct Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Conduct Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table118" checked>
                                                <label for="table118" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table119">
                                                <label for="table119" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table120">
                                                <label for="table120" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table121">
                                                <label for="table121" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table122">
                                                <label for="table122" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table123">
                                                <label for="table123" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table124">
                                                <label for="table124" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table125">
                                                <label for="table125" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table126">
                                                <label for="table126" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table127">
                                                <label for="table127" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table128">
                                                <label for="table128" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table129">
                                                <label for="table129" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table130">
                                                <label for="table130" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[conduct_disciplinary_info][]" class="custom-control-input" id="table131">
                                                <label for="table131" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Conduct Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                    <div class="form-group d-flex flex-wrap">
                                        <div class="mr-10">None / Display Only : </div>
                                        <input id="chk_9" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_9" tabindex="-1" role="dialog" aria-labelledby="modal_9Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_9Label">Edit Eligibility - Special Ed Indicators Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Special Ed Indicator Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table132" checked>
                                                <label for="table132" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table133">
                                                <label for="table133" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table134">
                                                <label for="table134" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table135">
                                                <label for="table135" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table136">
                                                <label for="table136" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table137">
                                                <label for="table137" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table138">
                                                <label for="table138" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table139">
                                                <label for="table139" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table140">
                                                <label for="table140" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table141">
                                                <label for="table141" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table142">
                                                <label for="table142" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table143">
                                                <label for="table143" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table144">
                                                <label for="table144" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[special_ed_indicators][]" class="custom-control-input" id="table145">
                                                <label for="table145" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Special Ed Indicators Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_10" tabindex="-1" role="dialog" aria-labelledby="modal_10Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_10Label">Edit Eligibility - Standardized Testing Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Standardized Testing Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="PreK" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table146" checked>
                                                <label for="table146" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="K" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table147">
                                                <label for="table147" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="1" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table148">
                                                <label for="table148" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="2" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table149">
                                                <label for="table149" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="3" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table150">
                                                <label for="table150" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="4" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table151">
                                                <label for="table151" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="5" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table152">
                                                <label for="table152" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="6" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table153">
                                                <label for="table153" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="7" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table154">
                                                <label for="table154" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="8" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table155">
                                                <label for="table155" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="9" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table156">
                                                <label for="table156" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="10" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table157">
                                                <label for="table157" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="11" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table158">
                                                <label for="table158" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" value="12" name="eligibility_grade_lavel[standardized_testing][]" class="custom-control-input" id="table159">
                                                <label for="table159" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Standardized Testing Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    {{--<div class="modal fade" id="modal_11" tabindex="-1" role="dialog" aria-labelledby="modal_11Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_11Label">Edit Eligibility - Recommendation Form 2 Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="">
                                <div class="form-group">
                                    <label class="control-label">Select Prior Developed Recommendation Form: : </label>
                                    <div class="">
                                        <select class="form-control custom-select" name="eligibility_grade_lavel[recommendation_form2][]">
                                            <option value="HCS STEM Teacher Recommendation">HCS STEM Teacher Recommendation</option>
                                            <option value="HCS Principal Recommendation">HCS Principal Recommendation</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>--}}
    </form>
@endsection
@section('scripts')
    <script src="{{asset('resources/assets/common/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('resources/assets/common/js/additional-methods.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('resources/assets/admin/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
    <script type="text/javascript">
        $(document).on("click",".add-option-list-custome",function(){
            var i = $(this).parent().siblings(".option-list-custome").children(".form-group").length + 1;
            var a = '<div class="form-group">'+
                '<label class="control-label">Option '+i+' : </label>'+
                '<div class=""><input type="text" class="form-control" value=""></div>'+
                '</div>';
            $(this).parent().siblings(".option-list-custome").append(a);
        });
        $(".chk_6").on("change", function(){
            if($(this).is(":checked")) {
                $(".custom-field-list").show();
            }
            else {
                $(".custom-field-list").hide();
            }
        })
        $(".chk_7").on("change", function(){
            if($(this).is(":checked")) {
                $(".option-list-outer").show();
            }
            else {
                $(".option-list-outer").hide();
            }
        })
        $(document).on("click", ".add-new" , function(){
            var cc = $("#first").clone().addClass('list').removeAttr("id");
            $("#inowtable tbody").append(cc);
        });
        function del(id){
            $(id).parents(".list").remove();
        }
        //$(document).ready(function(){
        //$('#cp2').colorpicker({
        //
        //});

        $(function () {
            $('#cp2').colorpicker().on('changeColor', function (e) {
                $('#chgcolor')[0].style.backgroundColor = e.color.toHex();
            });
        });
        $("#chk_03").on("change",function(){
            if($("#chk_03").is(":checked")) {
                $("#zone").show();
            }
            else {
                $("#zone").hide();
            }
        });

        //});
    </script>
    <script>
        $(".template-select").on("change",function(){
            var a = $(this).val();
            if(a == 4){
                $(".option4").addClass("d-none");
            }
            else {
                $(".option4").removeClass("d-none");
            }
        });
        $(".template-type").on("change",function(){
            var a = $(this).val();
            if(a == 1){
                $(".template-type-1").removeClass("d-none");
                $(".template-type-2").addClass("d-none");
            }
            else if(a == 2){
                $(".template-type-1").addClass("d-none");
                $(".template-type-2").removeClass("d-none");
            }
            else {
                $(".template-type-1").addClass("d-none");
                $(".template-type-2").addClass("d-none");
            }
        });
        $(document).on("click",".first-click",function(){
            var a = $(".template-select").val();
            if(a == 1) {
                $(".interview-list").removeClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").addClass('d-none');
            }
            else if(a == 2) {
                $(".interview-list").addClass('d-none');
                $(".audition-list").removeClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").addClass('d-none');
            }
            else if(a == 3) {
                $(".interview-list").addClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").removeClass('d-none');
                $(".academic-list").addClass('d-none');
            }
            else if(a == 4) {
                $(".interview-list").addClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").removeClass('d-none');
            }
            else {
                $(".interview-list").addClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").addClass('d-none');
            }
        });
        function custsort() {
            $(".form-list").sortable({
                handle: ".handle"
            });
            $(".form-list").disableSelection();
        };
        function custsort1() {
            $(".question-list").sortable({
                handle: ".handle1"
            });
            $(".question-list").disableSelection();
        };
        function custsort2() {
            $(".option-list").sortable({
                handle: ".handle2"
            });
            $(".option-list").disableSelection();
        };


        $(document).on("click", ".add-ranking" , function(){
            var i = $(this).parents(".template-type-2").find(".form-group").length + 1;
            var a = '<div class="form-group">'+
                '<label class="">Numeric Ranking '+i+' : </label>'+
                '<div class=""><input type="text" class="form-control"></div>'+
                '</div>';
            var cc = $(this).parents(".template-type-2").find(".mb-20");
            $(a).insertBefore(cc);
        });
        $(document).on("click", ".add-question" , function(){
            var i = $(this).parent().parent(".card-body").find(".question-list").children(".form-group").length + 1;
            var question =  '<div class="form-group border p-15">'+
                '<label class="control-label d-flex flex-wrap justify-content-between"><span><a href="javascript:void(0);" class="mr-10 handle1" title=""><i class="fas fa-arrows-alt"></i></a>Question '+i+' : </span>'+
                '<a href="javascript:void(0);" class="btn btn-secondary btn-sm add-option" title="">Add Option</a>'+
                '</label>'+
                '<div class=""><input type="text" class="form-control" value=""></div>'+
                '<div class="option-list mt-10"></div>'+
                '</div>';
            $(this).parent().parent(".card-body").find(".question-list").append(question);
            custsort1();
        });
        $(document).on("click", ".add-header" , function(){
            var i = $(".form-list").children(".card").length + 1;
            var header =    '<div class="card shadow">'+
                '<div class="card-header">'+
                '<div class="form-group">'+
                '<label class="control-label"><a href="javascript:void(0);" class="mr-10 handle" title=""><i class="fas fa-arrows-alt"></i></a> Header Name '+i+': </label>'+
                '<div class=""><input type="text" class="form-control" value=""></div>'+
                '</div>'+
                '</div>'+
                '<div class="card-body">'+
                '<div class="form-group text-right"><a href="javascript:void(0);" class="btn btn-secondary btn-sm add-question" title="">Add Question</a></div>'+
                '<div class="question-list p-15"></div>'+
                '</div>'+
                '</div>';
            $(this).parents(".card-body").find(".form-list").append(header);
            custsort();
        });
        $(document).on("click", ".add-option" , function(){
            var i = $(this).parent().parent(".form-group").children(".option-list").children(".form-group").length + 1;
            var option =    '<div class="form-group border p-10">'+
                '<div class="row">'+
                '<div class="col-12 col-md-7 d-flex flex-wrap align-items-center">'+
                '<a href="javascript:void(0);" class="mr-10 handle2" title=""><i class="fas fa-arrows-alt"></i></a>'+
                '<label for="" class="mr-10">Option '+i+' : </label>'+
                '<div class="flex-grow-1"><input type="text" class="form-control"></div>'+
                '</div>'+
                '<div class="col-10 col-md-5 d-flex flex-wrap align-items-center">'+
                '<label for="" class="mr-10">Point : </label>'+
                '<div class="flex-grow-1"><input type="text" class="form-control"></div>'+
                '</div>'+
                '</div>'+
                '</div>';
            $(this).parent().parent(".form-group").children(".option-list").append(option);
            custsort2();
        });
        ///method slection in selection tab
        $(function () {
            selectionMethod($('input:radio:checked'));
        });
        $("input[name='selection_method']").click(function () {
            selectionMethod(this);
        });
        function selectionMethod(method) {
            if($(method).attr('id')=='table27' && $(method).is(":checked"))
            {
                $('#seat_availability_enter_by').html('<option value="">Select</option><option value="Manual Entry">Manual Entry</option><option value="Calculation">Calculation</option>');

            }
            else if($(method).attr('id')=='table23' && $(method).is(":checked"))
            {
                $('#seat_availability_enter_by').html('<option value="">Select</option><option value="Calculation">Calculation</option>');
            }
            else if($(method).attr('id')=='table24' && $(method).is(":checked"))
            {
                $('#seat_availability_enter_by').html('<option value="">Select</option><option value="Calculation">Calculation</option>');
            }
            /*if($(method).attr('id')=='table27' && $(method).is(":checked"))
            {
                $('#racial_compo_sel,#racial_compo_seat').removeClass('d-none');
                $('#home_zone_sel,#Lottery_num_sel,#Lottery_num_seat,#home_zone_seat').addClass('d-none');
            }
            else if($(method).attr('id')=='table23' && $(method).is(":checked"))
            {
                $('#home_zone_sel,#home_zone_seat').removeClass('d-none');
                $('#racial_compo_sel,#Lottery_num_sel,#Lottery_num_seat,#racial_compo_seat').addClass('d-none');
            }
            else if($(method).attr('id')=='table24' && $(method).is(":checked"))
            {
                $('#Lottery_num_sel,#Lottery_num_seat').removeClass('d-none');
                $('#home_zone_sel,#racial_compo_sel,#racial_compo_seat,#home_zone_seat').addClass('d-none');
            }
            else{
                $(method).prop("checked", true);
            }*/
        }
        var committee_score_id;
        var rating_priority_id;
        var lottery_number_id;
        var combine_score_id;
        var audition_score_id;
        var final_score_id;
        $('.ranking_system').on('change',function () {
            if($(this).attr('id')=='committee_score') {
                committee_score_id = $("#committee_score option:selected").text();
            }
            else if($(this).attr('id')=='rating_priority')
            {
                rating_priority_id = $("#rating_priority option:selected").text();
            }
            else if($(this).attr('id')=='final_score')
            {
                final_score_id = $("#final_score option:selected").text();
            }
            else if($(this).attr('id')=='lottery_number')
            {
                lottery_number_id = $("#lottery_number option:selected").text();
            }
            else if($(this).attr('id')=='combine_score')
            {
                combine_score_id = $("#combine_score option:selected").text();
            }
            else if($(this).attr('id')=='audition_score')
            {
                audition_score_id = $("#audition_score option:selected").text();
            }
            $('option').each(function () {
                $(this).removeClass('d-none');
            });
            $("option[value=" + rating_priority_id + "] ,option[value=" + committee_score_id + "],option[value=" + lottery_number_id + "],option[value=" + combine_score_id + "],option[value=" + audition_score_id + "],option[value=" + final_score_id + "] ").each(function () {
                $(this).addClass('d-none');
            });
        });

        ///eligibility tab


    </script>
    <script>
        $(function () {
            disableCombinedScoring($('#combined_scoring'));
            $('#combined_scoring').on('change',function () {
                if ($('#basic_method_only').prop('checked')!=true)
                {
                    $('#basic_method_only').trigger('click');
                }
                disableCombinedScoring(this);
            });
            function disableCombinedScoring(checkbox) {
                if ($(checkbox).prop('checked')!=true)
                {
                    $("input[name='weight[]']").attr('disabled','disabled').val('');
                    $("select[name='determination_method[]']").each(function () {
                        $(this).find("option[value='Combined']").addClass('d-none').prop("selected", false);
                    });
                    $("#combined_eligibility").find("option[value='Weighted Scores']").addClass('d-none').prop("selected", false);
                }
                else{
                    $("input[name='weight[]']").removeAttr('disabled');
                    $("select[name='determination_method[]']").each(function () {
                        $(this).find("option[value='Combined']").removeClass('d-none');
                    });
                    $("#combined_eligibility").find("option[value='Weighted Scores']").removeClass('d-none');
                }
            }

            disableBasicMethod($('#basic_method_only'));
            $('#basic_method_only').on('change',function () {
                if ($('#combined_scoring').prop('checked')!=true)
                {
                    $('#combined_scoring').trigger('click');
                }
                disableBasicMethod(this);
            });
            function disableBasicMethod(checkbox) {
                if ($(checkbox).prop('checked')!=true)
                {
                    $("select[name='determination_method[]']").each(function () {
                        $(this).find("option[value='Basic']").addClass('d-none').prop("selected", false);
                    });
                    $("#combined_eligibility").find("option[value='Weighted Scores']").addClass('d-none').prop("selected", false);
                }
                else{
                    $("select[name='determination_method[]']").each(function () {
                        $(this).find("option[value='Basic']").removeClass('d-none');
                    });
                    $("#combined_eligibility").find("option[value='Weighted Scores']").removeClass('d-none');
                }
            }

        });
    </script>
@endsection
