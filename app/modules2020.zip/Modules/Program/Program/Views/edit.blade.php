@extends('layouts.admin.app')
@section('title')Edit Program  | {{config('APP_NAME',env("APP_NAME"))}}  @endsection
@section('styles')
    <style>
        input[type="checkbox"].styled-checkbox + label.label-xs {padding-left: 1.5rem;}
        .tooltip1 {
            position: relative;
            display: inline-block;
        }
        .tooltip1 .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: black;
            color: #fff;
            text-align: center;
            padding: 5px 0;
            border-radius: 6px;
            position: absolute;
            z-index: 1;
            margin-left: -60px;
            bottom: 115%;
            left: 50%;
        }
        .tooltip1:hover .tooltiptext {
            visibility: visible;
        }
        .tooltip1 .tooltiptext::after {
            content: " ";
            position: absolute;
            top: 100%; /* At the bottom of the tooltip */
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: black transparent transparent transparent;
        }
        .tooltip1 .tooltiptext-btm {top: 115%; bottom: auto;}
        .tooltip1 .tooltiptext-btm::after {
            content: "";
            position: absolute;
            top: -9px;
            bottom: auto;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent black transparent;
        }
    </style>
@endsection
@section('content')
    <div class="card shadow">
        <div class="card-body d-flex align-items-center justify-content-between flex-wrap">
            <div class="page-title mt-5 mb-5">Edit Program</div>
            <div class=""><a href="{{url('admin/Program')}}" class="btn btn-sm btn-secondary" title="">Back</a></div>
        </div>
    </div>
    <form action="{{url('admin/Program/update',$program->id)}}" method="post" name="edit_district" enctype= "multipart/form-data">
        {{csrf_field()}}
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item"><a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">General</a></li>
            <li class="nav-item"><a class="nav-link" id="eligibility-tab" data-toggle="tab" href="#eligibility" role="tab" aria-controls="eligibility" aria-selected="false">Eligibility</a></li>
            <!--<li class="nav-item"><a class="nav-link" id="config-tab" data-toggle="tab" href="#config" role="tab" aria-controls="config" aria-selected="false">Configurations</a></li>-->
            <li class="nav-item"><a class="nav-link" id="process-tab" data-toggle="tab" href="#process" role="tab" aria-controls="process" aria-selected="false">Selection</a></li>
            <!--<li class="nav-item"><a class="nav-link" id="recommendation-tab" data-toggle="tab" href="#recommendation" role="tab" aria-controls="recommendation" aria-selected="true">Add Recommendation</a></li>-->
        </ul>
        <div class="tab-content bordered" id="myTabContent">
            <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Program Set Up</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label">Program Name : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="name" value="{{$program->name}}">
                                        </div>
                                        @if($errors->first('name'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('name')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Applicant Group Filter 1 : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="applicant_filter1" value="{{$program->applicant_filter1}}">
                                        </div>
                                        @if($errors->first('applicant_filter1'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('applicant_filter1')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Applicant Group Filter 2 : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="applicant_filter2" value="{{$program->applicant_filter2}}">
                                        </div>
                                        @if($errors->first('applicant_filter2'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('applicant_filter2')}}
                                            </div>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Applicant Group Filter 3 : </label>
                                        <div class="">
                                            <input type="text" class="form-control" name="applicant_filter3" value="{{$program->applicant_filter3}}">
                                        </div>
                                        @if($errors->first('applicant_filter3'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('applicant_filter3')}}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>
                                        <div class="row flex-wrap">
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table25" name="grade_lavel[]" value="PreK" {{in_array('PreK',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table25" class="custom-control-label">PreK</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="K" class="custom-control-input" id="table06" {{in_array('K',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table06" class="custom-control-label">K</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="1" class="custom-control-input" id="table07" {{in_array('1',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table07" class="custom-control-label">1</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="2" class="custom-control-input" id="table08" {{in_array('2',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table08" class="custom-control-label">2</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="3" class="custom-control-input" id="table09" {{in_array('3',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table09" class="custom-control-label">3</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="4" class="custom-control-input" id="table10" {{in_array('4',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table10" class="custom-control-label">4</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="5" class="custom-control-input" id="table11" {{in_array('5',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table11" class="custom-control-label">5</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="6" class="custom-control-input" id="table12" {{in_array('6',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table12" class="custom-control-label">6</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="7" class="custom-control-input" id="table13" {{in_array('7',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table13" class="custom-control-label">7</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="8" class="custom-control-input" id="table14" {{in_array('8',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table14" class="custom-control-label">8</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="9" class="custom-control-input" id="table15" {{in_array('9',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table15" class="custom-control-label">9</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="10" class="custom-control-input" id="table16" {{in_array('10',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table16" class="custom-control-label">10</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]" value="11" class="custom-control-input" id="table17" {{in_array('11',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table17" class="custom-control-label">11</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-lg-2">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="grade_lavel[]"value="12" class="custom-control-input" id="table18" {{in_array('12',explode(',',$program->grade_lavel))?'checked':''}}>
                                                    <label for="table18" class="custom-control-label">12</label></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label"><strong>Parent Submission Form :</strong> </label>
                                        <div class="">
                                            <select class="form-control custom-select" name="parent_submission_form">
                                                <option value="">Choose an Option</option>
                                                <option value="HCS Basic Magnet" {{$program->parent_submission_form=='HCS Basic Magnet'?'selected':''}}>HCS Basic Magnet</option>
                                                <option value="HCS College Academy" {{$program->parent_submission_form=='HCS College Academy'?'selected':''}}>HCS College Academy</option>
                                                <option value="HCS AGT" {{$program->parent_submission_form=='HCS AGT'?'selected':''}}>HCS AGT</option>
                                                <option value="TCS Specialty Form" {{$program->parent_submission_form=='TCS Specialty Form'?'selected':''}}>TCS Specialty Form</option>
                                                <option value="MCPSS Magnet Form" {{$program->parent_submission_form=='MCPSS Magnet Form'?'selected':''}}>MCPSS Magnet Form</option>
                                                <option value="MPS Magnet Form" {{$program->parent_submission_form=='MPS Magnet Form'?'selected':''}}>MPS Magnet Form </option>
                                            </select>
                                        </div>
                                        <!--<div class="row flex-wrap">
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table00" checked>
                                                <label for="table00" class="custom-control-label">HCS Basic Magnet</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table01">
                                                <label for="table01" class="custom-control-label">HCS College Academy</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table02">
                                                <label for="table02" class="custom-control-label">HCS AGT</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table03">
                                                <label for="table03" class="custom-control-label">TCS Specialty Form</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table04">
                                                <label for="table04" class="custom-control-label">MCPSS Magnet Form</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table05">
                                                <label for="table05" class="custom-control-label">MPS Magnet Form </label></div>
                                            </div>
                                        </div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Priority Set Up</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Select Priority :</strong> </label>
                                        <div class="d-flex flex-wrap">
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="none" class="custom-control-input" id="table28" {{in_array('none',explode(',',$program->priority))?'checked':''}}>
                                                    <label for="table28" class="custom-control-label">None</label></div>
                                            </div>
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="1" class="custom-control-input" id="table29" {{in_array('1',explode(',',$program->priority))?'checked':''}}>
                                                    <label for="table29" class="custom-control-label">1</label></div>
                                            </div>
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="2" class="custom-control-input" id="table30" {{in_array('2',explode(',',$program->priority))?'checked':''}}>
                                                    <label for="table30" class="custom-control-label">2</label></div>
                                            </div>
                                            <div class="mr-20 w-90">
                                                <div class="custom-control custom-checkbox"><input type="checkbox" name="priority[]" value="3" class="custom-control-input" id="table31" {{in_array('3',explode(',',$program->priority))?'checked':''}}>
                                                    <label for="table31" class="custom-control-label">3</label></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="tab-pane fade" id="eligibility" role="tabpanel" aria-labelledby="eligibility-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Basic</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_00" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_01" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Recommendation Form : </label>
                                        <div class=""><input id="chk_02" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Writing Prompt : </label>
                                        <div class=""><input id="chk_03" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Audition : </label>
                                        <div class=""><input id="chk_04" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_05" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Conduct : </label>
                                        <div class=""><input id="chk_06" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Spec Ed Indicator : </label>
                                        <div class=""><input id="chk_07" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Interview Score : </label>
                                        <div class=""><input id="chk_08" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Standardized Testing : </label>
                                        <div class=""><input id="chk_09" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Combined</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_10" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_11" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_12" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Additional</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_13" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_14" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Recommendation Form : </label>
                                        <div class=""><input id="chk_15" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Writing Prompt : </label>
                                        <div class=""><input id="chk_16" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Audition : </label>
                                        <div class=""><input id="chk_17" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_18" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Conduct : </label>
                                        <div class=""><input id="chk_19" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Spec Ed Indicator : </label>
                                        <div class=""><input id="chk_20" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Interview Score : </label>
                                        <div class=""><input id="chk_21" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Standardized Testing : </label>
                                        <div class=""><input id="chk_22" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Final</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grades : </label>
                                        <div class=""><input id="chk_23" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Academic Grade Calculation : </label>
                                        <div class=""><input id="chk_24" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-group d-flex justify-content-between">
                                        <label class="control-label">Committee Score : </label>
                                        <div class=""><input id="chk_25" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            <div class="tab-pane fade" id="eligibility" role="tabpanel" aria-labelledby="eligibility-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header d-flex flex-wrap justify-content-between">
                            <div class="">Eligibility Determination Method</div>
                            <!--<div class=""><a href="add-eligibility-master.html" class="btn btn-secondary btn-sm" title="">Add Recommendation Form Eligibility</a></div>-->
                        </div>
                        <div class="card-body">
                            <div class="pb-10 d-flex flex-wrap justify-content-center align-items-center">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_0" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_1" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <!--<div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_2" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>-->
                                <div class="d-flex mb-10">
                                    <div class="mr-10 mt-5">Select Combined Eligibility : </div>
                                    <div class="">
                                        <select class="form-control custom-select">
                                            <option value="">Choose an Option</option>
                                            <option value="">Sum Scores</option>
                                            <option value="">Average Scores</option>
                                            <option value="">Weighted Scores</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                    <tr>
                                        <th class="align-middle">Eligibility Type</th>
                                        <th class="align-middle">Used in Determination Method</th>
                                        <th class="align-middle text-center">Eligibility Defined</th>
                                        <th class="align-middle text-center">Assigned Eligibility Name</th>
                                        <th class="align-middle text-center"><div class="tooltip1">Weight<span class="tooltiptext tooltiptext-btm">If combined and weighted is selected</span></div></th>
                                        <th class="align-middle text-center w-120">Active</th>
                                        <th class="align-middle text-center w-120">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {{--<tr>
                                        <td class="">Interview Score</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Interview Score 1</option>
                                                <option value="">Interview Score 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value="50%"></td>
                                        <td class="text-center"><input id="chk_00" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_1" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Grades</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Grades 1</option>
                                                <option value="">Grades 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value="25%"></td>
                                        <td class="text-center"><input id="chk_01" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_2" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Academic Grade Calculation</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Academic Grade 1</option>
                                                <option value="">Academic Grade 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_02" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_3" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Recommendation Form 1</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Recommendation Form 1</option>
                                                <option value="">Recommendation Form 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value="25%"></td>
                                        <td class="text-center"><input id="chk_03" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_4" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Writing Prompt</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Writing Prompt 1</option>
                                                <option value="">Writing Prompt 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_04" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_5" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Audition</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Audition 1</option>
                                                <option value="">Audition 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_05" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_6" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Committee Score</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/close.png" alt="Not Applicable"><span class="tooltiptext">Not Applicable</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Committee Score 1</option>
                                                <option value="">Committee Score 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_06" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_7" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Conduct Disciplinary Info</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Conduct Disciplinary Info 1</option>
                                                <option value="">Conduct Disciplinary Info 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_07" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_8" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Special Ed Indicators</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/close.png" alt="Not Applicable"><span class="tooltiptext">Not Applicable</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Special Ed Indicator 1</option>
                                                <option value="">Special Ed Indicator 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_08" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_9" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Standardized Testing</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/close.png" alt="Not Applicable"><span class="tooltiptext">Not Applicable</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Standardized Testing 1</option>
                                                <option value="">Standardized Testing 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_09" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_10" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td class="">Recommendation Form 2</td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Basic</option>
                                                <option value="">Combined</option>
                                            </select>
                                        </td>
                                        <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                        <td class="">
                                            <select class="form-control custom-select">
                                                <option value="">Choose an Option</option>
                                                <option value="">Recommendation Form 1</option>
                                                <option value="">Recommendation Form 2</option>
                                            </select>
                                        </td>
                                        <td class=""><input type="text" class="form-control" value=""></td>
                                        <td class="text-center"><input id="chk_10" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked></td>
                                        <td class="text-center"><a href="javascript:void(0);" data-toggle="modal" data-target="#modal_11" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a><a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a></td>
                                    </tr>--}}
                                    @forelse($programeligibilities as $key=>$programeligibility)
                                        @if($programeligibility->eligibility_type=='Interview Score')
                                            <tr>
                                            <td class="">
                                                Interview Score
                                                <input type="hidden" name="eligibility_type[]" value="Interview Score">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/right.png" alt="Assignment Completed"><span class="tooltiptext">Assignment Completed</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name=" assigned_eigibility_name[]">
                                                    <option value="Choose an Option" {{old('assigned_eigibility_name')=='Choose an Option'?'selected':''}}>Choose an Option</option>
                                                    <option value="Interview Score 1" {{old('assigned_eigibility_name')=='Interview Score 1'?'selected':''}}>Interview Score 1</option>
                                                    <option value="Interview Score 2" {{old('assigned_eigibility_name')=='Interview Score 2'?'selected':''}}>Interview Score 2</option>
                                                </select>
                                            </td>
                                            <td class="">
                                                <input type="text" name="weight[]" class="form-control" value="50%">
                                            </td>
                                            <td class="text-center">
                                                <input id="chk_00" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#modal_1" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a>
                                                {{--                                            <a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a>--}}
                                            </td>
                                        </tr>
                                        @endif
                                        @if($programeligibility->eligibility_type=='grade')
                                            <tr>
                                            <td class="">
                                                Grades
                                                <input type="hidden" name="eligibility_type[]" value="Grades">
                                            </td>
                                            <td class="">
                                                <select class="form-control custom-select" name="determination_method[]">
                                                    <option value="">Choose an Option</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="Combined">Combined</option>
                                                </select>
                                            </td>
                                            <td class="text-center"><div class="max-width-35 ml-auto mr-auto tooltip1"><img src="{{url('resources/assets/admin/images')}}/alert.png" alt="Awaiting Assignment"><span class="tooltiptext">Awaiting Assignment</span></div></td>
                                            <td class="">
                                                <select class="form-control custom-select" name=" assigned_eigibility_name[]">
                                                    <option value="Choose an Option" {{old('assigned_eigibility_name')=='Choose an Option'?'selected':''}}>Choose an Option</option>
                                                    <option value="Grades 1" {{old('assigned_eigibility_name')=='Grades 1'?'selected':''}}>Grades 1</option>
                                                    <option value="Grades 2" {{old('assigned_eigibility_name')=='Grades 2'?'selected':''}}>Grades 2</option>
                                                </select>
                                            </td>
                                            <td class="">
                                                <input type="text" name="weight[]" class="form-control" value="50%">
                                            </td>
                                            <td class="text-center">
                                                <input id="chk_00" type="checkbox" name="status[]" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#modal_2" class="font-18 ml-5 mr-5" title=""><i class="far fa-edit"></i></a>
                                                {{--                                            <a href="javascript:void(0);" class="font-18 ml-5 mr-5 text-danger" title=""><i class="far fa-trash-alt"></i></a>--}}
                                            </td>
                                        </tr>
                                        @endif
                                    @empty
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="tab-pane fade" id="config" role="tabpanel" aria-labelledby="config-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Writing Prompt</div>
                        <div class="card-body">
                            <div class="">
                                <div class="form-group row">
                                    <label class="control-label col-12 col-md-12">Writing Prompt</label>
                                    <div class="col-12 col-md-12">
                                        <input type="text" class="form-control" value="In the College Academy students are required to complete rigorous high school and college courses. Students will work with a diverse group of peers who are interested in a wide variety">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            <div class="tab-pane fade" id="process" role="tabpanel" aria-labelledby="process-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Selection Process Set Up</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-lg-12">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Ranking System :</strong> </label>
                                        <div class="row flex-wrap">
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Committee Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="committee_score" id="committee_score">
                                                        <option value="">NA</option>
                                                        <option value="1" {{$program->committee_score=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{$program->committee_score=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{$program->committee_score=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{$program->committee_score=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{$program->committee_score=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{$program->committee_score=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Priority : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="rating_priority" id="rating_priority">
                                                        <option value="">NA</option>
                                                        <option value="1" {{$program->rating_priority=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{$program->rating_priority=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{$program->rating_priority=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{$program->rating_priority=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{$program->rating_priority=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{$program->rating_priority=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Lottery Number : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="lottery_number" id="lottery_number">
                                                        <option value="">NA</option>
                                                        <option value="1" {{$program->lottery_number=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{$program->lottery_number=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{$program->lottery_number=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{$program->lottery_number=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{$program->lottery_number=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{$program->lottery_number=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Combined Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="combine_score" id="combine_score">
                                                        <option value="">NA</option>
                                                        <option value="1" {{$program->combine_score=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{$program->combine_score=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{$program->combine_score=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{$program->combine_score=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{$program->combine_score=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{$program->combine_score=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Audition Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="audition_score" id="audition_score">
                                                        <option value="">NA</option>
                                                        <option value="1" {{$program->audition_score=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{$program->audition_score=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{$program->audition_score=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{$program->audition_score=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{$program->audition_score=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{$program->audition_score=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 form-group">
                                                <label for="table26" class="mr-10">Final Score : </label>
                                                <div class="">
                                                    <select class="form-control custom-select ranking_system" name="final_score" id="final_score">audition_scorefinal_score
                                                        <option value="">NA</option>
                                                        <option value="1" {{$program->final_score=='1'?'selected':''}}>1</option>
                                                        <option value="2" {{$program->final_score=='2'?'selected':''}}>2</option>
                                                        <option value="3" {{$program->final_score=='3'?'selected':''}}>3</option>
                                                        <option value="4" {{$program->final_score=='4'?'selected':''}}>4</option>
                                                        <option value="5" {{$program->final_score=='5'?'selected':''}}>5</option>
                                                        <option value="6" {{$program->final_score=='6'?'selected':''}}>6</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-12">
                                    <div class="form-group">
                                        <label class="control-label"><strong>Selection Method :</strong> </label>
                                        <div class="row flex-wrap">
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-radio"><input type="radio" name="selection_method"value="Racial Composition" class="custom-control-input" id="table27" {{$program->selection_method=='Racial Composition'?'checked':''}}>
                                                    <label for="table27" class="custom-control-label">Racial Composition</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-radio"><input type="radio" name="selection_method" value="Home Zone Placement" class="custom-control-input" id="table23" {{$program->selection_method=='Home Zone Placement'?'checked':''}}>
                                                    <label for="table23" class="custom-control-label">Home Zone Placement</label></div>
                                            </div>
                                            <div class="col-12 col-sm-4">
                                                <div class="custom-control custom-radio"><input type="radio" name="selection_method" value="Lottery Number Only" class="custom-control-input" id="table24" {{$program->selection_method=='Lottery Number Only'?'checked':''}}>
                                                    <label for="table24" class="custom-control-label">Lottery Number Only</label></div>
                                            </div>
                                        </div>
                                        @if($errors->first('selection_method'))
                                            <div class="mb-1 text-danger">
                                                {{$errors->first('selection_method')}}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-12 col-lg-12">
                                    <div class="row flex-wrap">
                                        <div class="col-12 form-group">
                                            <label for="table26" class="mr-10"><strong>Selection By : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="selection_by" id="selection_by">
                                                    <option value="">Select</option>
                                                    <option value="Program Name" {{$program->selection_by=='Program Name'?'selected':''}}>Program Name</option>
                                                    <option value="Application Filter 1" {{$program->selection_by=='Application Filter 1'?'selected':''}}>Application Filter 1</option>
                                                    <option value="Application Filter 2" {{$program->selection_by=='Application Filter 2'?'selected':''}}>Application Filter 2</option>
                                                    <option value="Application Filter 3" {{$program->selection_by=='Application Filter 3'?'selected':''}}>Application Filter 3</option>
                                                </select>
                                            </div>
                                            @if($errors->first('selection_by'))
                                                <div class="mb-1 text-danger">
                                                    {{ $errors->first('selection_by')}}
                                                </div>
                                            @endif
                                        </div>

                                       {{-- <div class="col-12 col-sm-4 form-group">
                                            <label for="table26" class="mr-10"><strong>Selection By : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" id="home_zone_sel">
                                                    <option value="">Select</option>
                                                    <option value="">Program Name</option>
                                                    <option value="">Application Filter 1</option>
                                                    <option value="">Application Filter 2</option>
                                                    <option value="">Application Filter 3</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-4 form-group">
                                            <label for="table26" class="mr-10"><strong>Selection By : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" id="Lottery_num_sel">
                                                    <option value="">Select</option>
                                                    <option value="">Program Name</option>
                                                    <option value="">Application Filter 1</option>
                                                    <option value="">Application Filter 2</option>
                                                    <option value="">Application Filter 3</option>
                                                </select>
                                            </div>
                                        </div>--}}
                                        <div class="col-12 form-group">
                                            <label for="table26" class="mr-10"><strong>Seat Availability Entered by : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" name="seat_availability_enter_by" id="seat_availability_enter_by">
                                                    <option value="">Select</option>
                                                    <option value="Manual Entry" {{$program->seat_availability_enter_by=='Manual Entry'?'selected':''}}>Manual Entry</option>
                                                    <option value="Calculation" {{$program->seat_availability_enter_by=='Calculation'?'selected':''}}>Calculation</option>
                                                </select>
                                            </div>
                                        </div>
                                        @if($errors->first('seat_availability_enter_by'))
                                            <div class="mb-1 text-danger">
                                                {{ $errors->first('seat_availability_enter_by')}}
                                            </div>
                                        @endif
                                       {{-- <div class="col-12 col-sm-4 form-group">
                                            <label for="table26" class="mr-10"><strong>Seat Availability Entered by : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" id="home_zone_seat">
                                                    <option value="">Select</option>
                                                    <option value="">Manual Entry</option>
                                                    <option value="">Calculation</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-4 form-group">
                                            <label for="table26" class="mr-10"><strong>Seat Availability Entered by : </strong></label>
                                            <div class="">
                                                <select class="form-control custom-select" id="Lottery_num_seat">
                                                    <option value="">Select</option>
                                                    <option value="">Manual Entry</option>
                                                    <option value="">Calculation</option>
                                                </select>
                                            </div>
                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="tab-pane fade" id="recommendation" role="tabpanel" aria-labelledby="recommendation-tab">
                <div class="">
                    <div class="card shadow">
                        <div class="card-header">Recommendation Form</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label">Eligibility Name : </label>
                                <div class=""><input type="text" class="form-control" value=""></div>
                            </div>
                            <div class="form-group text-right"><a href="javascript:void(0);" class="btn btn-secondary btn-sm add-header" title="">Add Header</a></div>
                            <div class="form-list"></div>
                        </div>
                    </div>
                </div>
            </div>-->
        </div>

        <div class="box content-header-floating" id="listFoot">
            <div class="row">
                <div class="col-lg-12 text-right hidden-xs float-right">
                    <button type="submit" class="btn btn-warning btn-xs"><i class="fa fa-save"></i> Save </button>
                    <button type="submit" class="btn btn-success btn-xs" name="save_edit" value="save_edit"><i class="fa fa-save"></i> Save &amp; Edit</button>
                    <a class="btn btn-danger btn-xs" onclick="deletefunction({{$program->id}})" href="javascript:void(0)"><i class="fa fa-trash"></i> Delete</a>
                </div>
            </div>
        </div>
    </form>
    <!-- Modal -->
    <div class="modal fade" id="modal_1" tabindex="-1" role="dialog" aria-labelledby="modal_1Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_1Label">Edit Eligibility - Interview Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Interview Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Interview Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="modal_2" tabindex="-1" role="dialog" aria-labelledby="modal_2Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_2Label">Edit Eligibility - Grades Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Grade Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Grades Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_3" tabindex="-1" role="dialog" aria-labelledby="modal_3Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_3Label">Edit Eligibility - Academic Grade Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Academic Grade Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Academic Grade Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_4" tabindex="-1" role="dialog" aria-labelledby="modal_4Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_4Label">Edit Eligibility - Recommendation Form 1</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="">
                                <div class="form-group">
                                    <label class="control-label">Select Prior Developed Recommendation Form: : </label>
                                    <div class="">
                                        <select class="form-control custom-select">
                                            <option value="">HCS STEM Teacher Recommendation</option>
                                            <option value="">HCS Principal Recommendation</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_5" tabindex="-1" role="dialog" aria-labelledby="modal_5Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_5Label">Edit Eligibility - Writing Prompt Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Writing Prompt Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Writing Prompt Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                    <div class="form-group d-flex flex-wrap">
                                        <div class="mr-10">None / Display Only : </div>
                                        <input id="chk_9" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_6" tabindex="-1" role="dialog" aria-labelledby="modal_6Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_6Label">Edit Eligibility - Audition Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Audition Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Audition Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_7" tabindex="-1" role="dialog" aria-labelledby="modal_7Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_7Label">Edit Eligibility - Committee Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Committee Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Committee Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_8" tabindex="-1" role="dialog" aria-labelledby="modal_8Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_8Label">Edit Eligibility - Conduct Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Conduct Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Conduct Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                    <div class="form-group d-flex flex-wrap">
                                        <div class="mr-10">None / Display Only : </div>
                                        <input id="chk_9" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_9" tabindex="-1" role="dialog" aria-labelledby="modal_9Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_9Label">Edit Eligibility - Special Ed Indicators Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Special Ed Indicator Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Special Ed Indicators Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                            </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_10" tabindex="-1" role="dialog" aria-labelledby="modal_10Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_10Label">Edit Eligibility - Standardized Testing Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-header">Available Grade Level (Check all that apply)</div>
                        <div class="card-body">
                            <div class="">
                                <!--<div class="form-group">
                                    <label for="" class="">Name of Standardized Testing Score : </label>
                                    <div class=""><input type="text" class="form-control"></div>
                                </div>-->
                                <div class="form-group">
                                    <!--<label class="control-label"><strong>Available Grade Level (Check all that apply) :</strong> </label>-->
                                    <div class="row flex-wrap">
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table32" checked>
                                                <label for="table32" class="custom-control-label">PreK</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table33">
                                                <label for="table33" class="custom-control-label">K</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table34">
                                                <label for="table34" class="custom-control-label">1</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table35">
                                                <label for="table35" class="custom-control-label">2</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table36">
                                                <label for="table36" class="custom-control-label">3</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table37">
                                                <label for="table37" class="custom-control-label">4</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table38">
                                                <label for="table38" class="custom-control-label">5</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table39">
                                                <label for="table39" class="custom-control-label">6</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table40">
                                                <label for="table40" class="custom-control-label">7</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table41">
                                                <label for="table41" class="custom-control-label">8</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table42">
                                                <label for="table42" class="custom-control-label">9</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table43">
                                                <label for="table43" class="custom-control-label">10</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table44">
                                                <label for="table44" class="custom-control-label">11</label></div>
                                        </div>
                                        <div class="col-12 col-sm-4 col-lg-2">
                                            <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="table45">
                                                <label for="table45" class="custom-control-label">12</label></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="">
                                    <label class="control-label"><strong>Select Standardized Testing Score Value Method (Select only one) :</strong> </label>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Yes / No Selection : </div>
                                            <input id="chk_6" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_6" data-size="Small" checked>
                                        </div>
                                        <div class="custom-field-list">
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for YES : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Enter Custom Field Label for NO : </label>
                                            <div class=""><input type="text" class="form-control" value=""></div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="form-group d-flex flex-wrap">
                                            <div class="mr-10">Numerical Ranking : </div>
                                            <input id="chk_7" type="checkbox" class="js-switch js-switch-1 js-switch-xs chk_7" data-size="Small" checked>
                                        </div>
                                        <div class="option-list-outer">
                                            <div class="option-list-custome">
                                                <div class="form-group">
                                                    <label class="control-label">Option 1 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 2 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 3 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label">Option 4 : </label>
                                                    <div class=""><input type="text" class="form-control" value=""></div>
                                                </div>
                                            </div>
                                            <div class=""><a href="javascript:void(0);" class="font-18 add-option-list-custome" title=""><i class="fas fa-plus-square"></i></a></div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_11" tabindex="-1" role="dialog" aria-labelledby="modal_11Label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title" id="modal_11Label">Edit Eligibility - Recommendation Form 2 Score</div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div class="modal-body">
                    <div class="card shadow mb-20 d-none">
                        <div class="card-header">Used in Determination Method</div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap">
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Basic Method Only Active : </div>
                                    <input id="chk_3" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                                <div class="d-flex mb-10 mr-30">
                                    <div class="mr-10">Combined Scoring Active : </div>
                                    <input id="chk_4" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small" checked>
                                </div>
                                <div class="d-flex mb-10">
                                    <div class="mr-10">Final Scoring Active : </div>
                                    <input id="chk_5" type="checkbox" class="js-switch js-switch-1 js-switch-xs" data-size="Small">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="">
                                <div class="form-group">
                                    <label class="control-label">Select Prior Developed Recommendation Form: : </label>
                                    <div class="">
                                        <select class="form-control custom-select">
                                            <option value="">HCS STEM Teacher Recommendation</option>
                                            <option value="">HCS Principal Recommendation</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script src="{{asset('resources/assets/common/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('resources/assets/common/js/additional-methods.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('resources/assets/admin/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
    <script type="text/javascript">
        $(document).on("click",".add-option-list-custome",function(){
            var i = $(this).parent().siblings(".option-list-custome").children(".form-group").length + 1;
            var a = '<div class="form-group">'+
                '<label class="control-label">Option '+i+' : </label>'+
                '<div class=""><input type="text" class="form-control" value=""></div>'+
                '</div>';
            $(this).parent().siblings(".option-list-custome").append(a);
        });
        $(".chk_6").on("change", function(){
            if($(this).is(":checked")) {
                $(".custom-field-list").show();
            }
            else {
                $(".custom-field-list").hide();
            }
        })
        $(".chk_7").on("change", function(){
            if($(this).is(":checked")) {
                $(".option-list-outer").show();
            }
            else {
                $(".option-list-outer").hide();
            }
        })
        $(document).on("click", ".add-new" , function(){
            var cc = $("#first").clone().addClass('list').removeAttr("id");
            $("#inowtable tbody").append(cc);
        });
        function del(id){
            $(id).parents(".list").remove();
        }
        //$(document).ready(function(){
        //$('#cp2').colorpicker({
        //
        //});

        $(function () {
            $('#cp2').colorpicker().on('changeColor', function (e) {
                $('#chgcolor')[0].style.backgroundColor = e.color.toHex();
            });
        });
        $("#chk_03").on("change",function(){
            if($("#chk_03").is(":checked")) {
                $("#zone").show();
            }
            else {
                $("#zone").hide();
            }
        });

        //});
    </script>
    <script>
        $(".template-select").on("change",function(){
            var a = $(this).val();
            if(a == 4){
                $(".option4").addClass("d-none");
            }
            else {
                $(".option4").removeClass("d-none");
            }
        });
        $(".template-type").on("change",function(){
            var a = $(this).val();
            if(a == 1){
                $(".template-type-1").removeClass("d-none");
                $(".template-type-2").addClass("d-none");
            }
            else if(a == 2){
                $(".template-type-1").addClass("d-none");
                $(".template-type-2").removeClass("d-none");
            }
            else {
                $(".template-type-1").addClass("d-none");
                $(".template-type-2").addClass("d-none");
            }
        });
        $(document).on("click",".first-click",function(){
            var a = $(".template-select").val();
            if(a == 1) {
                $(".interview-list").removeClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").addClass('d-none');
            }
            else if(a == 2) {
                $(".interview-list").addClass('d-none');
                $(".audition-list").removeClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").addClass('d-none');
            }
            else if(a == 3) {
                $(".interview-list").addClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").removeClass('d-none');
                $(".academic-list").addClass('d-none');
            }
            else if(a == 4) {
                $(".interview-list").addClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").removeClass('d-none');
            }
            else {
                $(".interview-list").addClass('d-none');
                $(".audition-list").addClass('d-none');
                $(".committee-list").addClass('d-none');
                $(".academic-list").addClass('d-none');
            }
        });
        function custsort() {
            $(".form-list").sortable({
                handle: ".handle"
            });
            $(".form-list").disableSelection();
        };
        function custsort1() {
            $(".question-list").sortable({
                handle: ".handle1"
            });
            $(".question-list").disableSelection();
        };
        function custsort2() {
            $(".option-list").sortable({
                handle: ".handle2"
            });
            $(".option-list").disableSelection();
        };


        $(document).on("click", ".add-ranking" , function(){
            var i = $(this).parents(".template-type-2").find(".form-group").length + 1;
            var a = '<div class="form-group">'+
                '<label class="">Numeric Ranking '+i+' : </label>'+
                '<div class=""><input type="text" class="form-control"></div>'+
                '</div>';
            var cc = $(this).parents(".template-type-2").find(".mb-20");
            $(a).insertBefore(cc);
        });
        $(document).on("click", ".add-question" , function(){
            var i = $(this).parent().parent(".card-body").find(".question-list").children(".form-group").length + 1;
            var question =  '<div class="form-group border p-15">'+
                '<label class="control-label d-flex flex-wrap justify-content-between"><span><a href="javascript:void(0);" class="mr-10 handle1" title=""><i class="fas fa-arrows-alt"></i></a>Question '+i+' : </span>'+
                '<a href="javascript:void(0);" class="btn btn-secondary btn-sm add-option" title="">Add Option</a>'+
                '</label>'+
                '<div class=""><input type="text" class="form-control" value=""></div>'+
                '<div class="option-list mt-10"></div>'+
                '</div>';
            $(this).parent().parent(".card-body").find(".question-list").append(question);
            custsort1();
        });
        $(document).on("click", ".add-header" , function(){
            var i = $(".form-list").children(".card").length + 1;
            var header =    '<div class="card shadow">'+
                '<div class="card-header">'+
                '<div class="form-group">'+
                '<label class="control-label"><a href="javascript:void(0);" class="mr-10 handle" title=""><i class="fas fa-arrows-alt"></i></a> Header Name '+i+': </label>'+
                '<div class=""><input type="text" class="form-control" value=""></div>'+
                '</div>'+
                '</div>'+
                '<div class="card-body">'+
                '<div class="form-group text-right"><a href="javascript:void(0);" class="btn btn-secondary btn-sm add-question" title="">Add Question</a></div>'+
                '<div class="question-list p-15"></div>'+
                '</div>'+
                '</div>';
            $(this).parents(".card-body").find(".form-list").append(header);
            custsort();
        });
        $(document).on("click", ".add-option" , function(){
            var i = $(this).parent().parent(".form-group").children(".option-list").children(".form-group").length + 1;
            var option =    '<div class="form-group border p-10">'+
                '<div class="row">'+
                '<div class="col-12 col-md-7 d-flex flex-wrap align-items-center">'+
                '<a href="javascript:void(0);" class="mr-10 handle2" title=""><i class="fas fa-arrows-alt"></i></a>'+
                '<label for="" class="mr-10">Option '+i+' : </label>'+
                '<div class="flex-grow-1"><input type="text" class="form-control"></div>'+
                '</div>'+
                '<div class="col-10 col-md-5 d-flex flex-wrap align-items-center">'+
                '<label for="" class="mr-10">Point : </label>'+
                '<div class="flex-grow-1"><input type="text" class="form-control"></div>'+
                '</div>'+
                '</div>'+
                '</div>';
            $(this).parent().parent(".form-group").children(".option-list").append(option);
            custsort2();
        });
        ///method slection in selection tab
       /* $(function () {
            selectionMethod($('input:radio:checked'));
        });*/
        $("input[name='selection_method']").click(function () {
            selectionMethod(this);
        });
        function selectionMethod(method) {
            if($(method).attr('id')=='table27' && $(method).is(":checked"))
            {
                $('#seat_availability_enter_by').html('<option value="">Select</option><option value="Manual Entry">Manual Entry</option><option value="Calculation">Calculation</option>');

            }
            else if($(method).attr('id')=='table23' && $(method).is(":checked"))
            {
                $('#seat_availability_enter_by').html('<option value="">Select</option><option value="Calculation">Calculation</option>');
            }
            else if($(method).attr('id')=='table24' && $(method).is(":checked"))
            {
                $('#seat_availability_enter_by').html('<option value="">Select</option><option value="Calculation">Calculation</option>');
            }
        }
        var committee_score_id;
        var rating_priority_id;
        var lottery_number_id;
        var combine_score_id;
        var audition_score_id;
        var final_score_id;
        $(function () {
            committee_score_id= $('#committee_score').children("option:selected").text();
            rating_priority_id = $('#rating_priority').children("option:selected").text();
            lottery_number_id = $('#final_score').children("option:selected").text();
            combine_score_id = $('#lottery_number').children("option:selected").text();
            audition_score_id = $('#combine_score').children("option:selected").text();
            final_score_id = $('#audition_score').children("option:selected").text();
            $('option').each(function () {
                $(this).removeClass('d-none');
            });
            $("option[value=" + rating_priority_id + "] ,option[value=" + committee_score_id + "],option[value=" + lottery_number_id + "],option[value=" + combine_score_id + "],option[value=" + audition_score_id + "],option[value=" + final_score_id + "] ").each(function () {
                $(this).addClass('d-none');
            });
        });
        function rakingSystem(attr)
        {
            if($(attr).attr('id')=='committee_score') {
                committee_score_id = $("#committee_score option:selected").text();
            }
            else if($(attr).attr('id')=='rating_priority')
            {
                rating_priority_id = $("#rating_priority option:selected").text();
            }
            else if($(attr).attr('id')=='final_score')
            {
                final_score_id = $("#final_score option:selected").text();
            }
            else if($(attr).attr('id')=='lottery_number')
            {
                lottery_number_id = $("#lottery_number option:selected").text();
            }
            else if($(attr).attr('id')=='combine_score')
            {
                combine_score_id = $("#combine_score option:selected").text();
            }
            else if($(attr).attr('id')=='audition_score')
            {
                audition_score_id = $("#audition_score option:selected").text();
            }
            $('option').each(function () {
                $(this).removeClass('d-none');
            });
            $("option[value=" + rating_priority_id + "] ,option[value=" + committee_score_id + "],option[value=" + lottery_number_id + "],option[value=" + combine_score_id + "],option[value=" + audition_score_id + "],option[value=" + final_score_id + "] ").each(function () {
                $(this).addClass('d-none');
            });
        }
        var deletefunction = function(id){
            swal({
                title: "Are you sure you would like to delete this Program ?",
                text: "",
                // type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes",
                closeOnConfirm: false
            }).then(function() {
                window.location.href = '{{url('/')}}/admin/Program/delete/'+id;
            });
        };
    </script>
@endsection
